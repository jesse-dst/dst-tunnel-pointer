#!/bin/bash
# DST Fleet — patch 7 (2026-09-15): one-click "Link HubSpot contact" for a serial
# - Rig page: Customer field gets Link / Change. Search HubSpot by name, email,
#   phone or pasted contact URL; pick; done. Writes serial -> System Serial
#   Number, DMS login -> FJD Login Info, attaches the serial's deal; stores a
#   manual row in livedata.db (matcher never overwrites); pushes the map now.
# - Live board: link icon on every row (orange when no customer).
# - Customer matching lists: Link button per row; linked rigs drop off the list.
# - ?link=1 on the rig page auto-opens the dialog (Live Map deep link).
# - GET /api/hubspot/contacts?q=  POST/DELETE /api/rig/:sn/contact  GET /api/live/manual-links
# Usage: cd /tmp && tar xzf fleet_patch7.tgz && bash fleet_patch7/apply.sh
set -u
REPO=/Volumes/SB-XTM5/dst-fleet-data/dst-fleet-reports
SRC=/tmp/fleet_patch7/files
STAMP=$(date +%Y%m%d-%H%M%S)
BK=/tmp/fleet_patch7/backup-$STAMP
exec > >(tee -a /tmp/fleet_patch7/result.log) 2>&1
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
cd "$REPO" || { echo "FAIL: repo not found"; exit 2; }
echo "== repo head: $(git rev-parse --short HEAD)"
FILES="server/live.ts server/routes.ts client/src/pages/rig-detail.tsx client/src/pages/live.tsx"
NEW="server/hubspot-link.ts client/src/components/contact-picker.tsx"
for f in $FILES; do mkdir -p "$BK/$(dirname $f)"; cp "$f" "$BK/$f"; done
for f in $FILES $NEW; do cp "$SRC/$f" "$f" || { echo "FAIL: cannot write $f"; exit 3; }; done

echo "== build"
if ! npm run build > /tmp/fleet_patch7/build-$STAMP.log 2>&1; then
  echo "FAIL: build failed — restoring previous files"; tail -30 /tmp/fleet_patch7/build-$STAMP.log
  for f in $FILES; do cp "$BK/$f" "$f"; done; rm -f $NEW; exit 4
fi
echo "== build ok"

G="git -c user.name=dst-fleet -c user.email=support@deepsandtech.com"
$G add $FILES $NEW
$G commit -q -m "Manual serial -> HubSpot contact link: search/link/unlink API, rig page + live board + review list buttons, map push" 2>/dev/null && echo "== committed $(git rev-parse --short HEAD)" || echo "== commit skipped"

echo "== restarting com.dst.fleet"
launchctl kickstart -k gui/$(id -u)/com.dst.fleet
for i in $(seq 1 30); do sleep 2; curl -sf -m 3 http://127.0.0.1:5050/api/auth/me >/dev/null 2>&1 && break; done

echo "== smoke: contact search (read-only HubSpot call)"
curl -s -m 25 "http://127.0.0.1:5050/api/hubspot/contacts?q=jensen" | head -c 700; echo
echo "== smoke: rig endpoint carries source + hubspotLinkConfigured"
curl -s -m 10 "http://127.0.0.1:5050/api/rig/FJLQ17225300141ZC" | grep -o '"hubspot":{[^}]*}' | head -c 400; echo
curl -s -m 10 "http://127.0.0.1:5050/api/rig/FJLQ17225300141ZC" | grep -o '"hubspotLinkConfigured":[a-z]*'
echo "== smoke: manual-links log (empty until first use)"
curl -s -m 10 "http://127.0.0.1:5050/api/live/manual-links" | head -c 200; echo
echo "== DONE. Hard-refresh the Fleet app; open any rig page -> Customer -> Link."
