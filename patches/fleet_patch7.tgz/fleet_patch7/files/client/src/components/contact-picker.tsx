import { useEffect, useRef, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ExternalLink, Link2, Loader2, Search, UserPlus } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export type ContactHit = {
  id: string; name: string; email: string | null; phone: string | null; location: string | null;
  serials: string[]; logins: string[]; tractor: string | null; created: string | null; link: string;
};
type LinkResult = { ok: true; sn: string; contact: ContactHit; source: string; hubspot: string[]; mapPushed: boolean };

/**
 * "Link HubSpot contact" dialog. Search by name / email / phone / HubSpot URL,
 * pick a contact, and the serial is linked in the Fleet app, written to the
 * HubSpot contact (serial + FJD login + serial deal) and pushed to the Live Map.
 */
export function ContactPicker({
  sn, open, onOpenChange, initialQuery, login, current, onLinked,
}: {
  sn: string; open: boolean; onOpenChange: (o: boolean) => void;
  initialQuery?: string; login?: string | null;
  current?: { name: string | null; link: string | null; source?: string | null } | null;
  onLinked?: (r: LinkResult) => void;
}) {
  const [q, setQ] = useState(initialQuery ?? "");
  const [debounced, setDebounced] = useState(q);
  const [writeHubspot, setWriteHubspot] = useState(true);
  const inputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  useEffect(() => { if (open) { setQ(initialQuery ?? ""); setDebounced(initialQuery ?? ""); setTimeout(() => inputRef.current?.focus(), 50); } }, [open, initialQuery]);
  useEffect(() => { const t = setTimeout(() => setDebounced(q), 350); return () => clearTimeout(t); }, [q]);

  const search = useQuery<{ configured: boolean; results: ContactHit[] }>({
    queryKey: ["/api/hubspot/contacts?q=" + encodeURIComponent(debounced)],
    enabled: open && debounced.trim().length >= 2,
    staleTime: 60000,
  });

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/rig", sn] });
    queryClient.invalidateQueries({ predicate: (q) => String(q.queryKey[0] ?? "").startsWith("/api/live") });
  };
  const link = useMutation({
    mutationFn: async (contactId: string) => {
      const r = await apiRequest("POST", `/api/rig/${sn}/contact`, { contactId, writeHubspot });
      return (await r.json()) as LinkResult;
    },
    onSuccess: (r) => {
      invalidate();
      toast({
        title: `${sn} → ${r.contact.name}`,
        description: [
          r.hubspot.length ? `HubSpot: ${r.hubspot.join("; ")}` : (writeHubspot ? "HubSpot already had this serial and login." : "HubSpot not changed."),
          r.mapPushed ? "Live Map updated." : "Live Map will update on the next push.",
        ].join(" "),
      });
      onLinked?.(r);
      onOpenChange(false);
    },
    onError: (e: Error) => toast({ title: "Link failed", description: e.message, variant: "destructive" }),
  });
  const unlink = useMutation({
    mutationFn: async () => { await apiRequest("DELETE", `/api/rig/${sn}/contact`); },
    onSuccess: () => { invalidate(); toast({ title: `${sn} unlinked`, description: "Fleet app only — HubSpot was not changed. The matcher may re-fill it on its next run." }); onOpenChange(false); },
    onError: (e: Error) => toast({ title: "Unlink failed", description: e.message, variant: "destructive" }),
  });

  const results = search.data?.results ?? [];
  const holdsAlready = (c: ContactHit) => c.serials.includes(sn.toUpperCase());
  const hasLogin = (c: ContactHit) => !!login && (c.logins.includes(login.toLowerCase()) || c.email?.toLowerCase() === login.toLowerCase());

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] w-[calc(100vw-1.5rem)] max-w-xl overflow-y-auto p-4 sm:p-6" data-testid="dialog-contact-picker">
        <DialogHeader>
          <DialogTitle className="flex flex-wrap items-center gap-2 text-base">
            <Link2 className="h-4 w-4 text-[#71A8A3]" /> Link <span className="font-mono">{sn}</span> to a HubSpot contact
          </DialogTitle>
        </DialogHeader>
        {current?.name && (
          <div className="rounded border border-border/60 bg-muted/40 px-3 py-2 text-xs">
            Currently: <a href={current.link ?? "#"} target="_blank" rel="noreferrer" className="font-semibold underline-offset-2 hover:underline">{current.name}</a>
            {current.source ? <span className="text-muted-foreground"> · {current.source.startsWith("manual") ? "linked by hand" : `auto (${current.source})`}</span> : null}
            <Button size="sm" variant="ghost" className="ml-2 h-6 px-2 text-xs text-[#B22C2B]" disabled={unlink.isPending} onClick={() => unlink.mutate()} data-testid="button-unlink-contact">
              {unlink.isPending ? "…" : "Unlink"}
            </Button>
          </div>
        )}
        {login ? <div className="text-xs text-muted-foreground">This unit logs in to FJD as <span className="font-mono">{login}</span>.</div> : null}
        <div className="relative">
          <Search className="pointer-events-none absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            ref={inputRef} value={q} onChange={(e) => setQ(e.target.value)}
            placeholder="Name, email, phone, or paste a HubSpot contact URL"
            className="pl-8" autoComplete="off" inputMode="search" data-testid="input-contact-search"
          />
        </div>
        <label className="flex items-center gap-2 text-xs">
          <Switch checked={writeHubspot} onCheckedChange={setWriteHubspot} data-testid="switch-write-hubspot" />
          Also write to HubSpot: add serial to System Serial Number{login ? ", add the FJD login" : ""}, attach the serial's deal
        </label>
        <div className="min-h-[6rem] space-y-1">
          {debounced.trim().length < 2 ? (
            <div className="py-4 text-center text-xs text-muted-foreground">Type at least 2 characters.</div>
          ) : search.isLoading ? (
            <div className="flex items-center justify-center gap-2 py-4 text-xs text-muted-foreground"><Loader2 className="h-3.5 w-3.5 animate-spin" /> Searching HubSpot…</div>
          ) : search.isError ? (
            <div className="py-4 text-center text-xs text-[#B22C2B]">{(search.error as Error).message}</div>
          ) : results.length === 0 ? (
            <div className="py-4 text-center text-xs text-muted-foreground">
              No HubSpot contact matches.{" "}
              <a className="underline-offset-2 hover:underline" target="_blank" rel="noreferrer"
                href={`https://app.hubspot.com/contacts/23533734/objects/0-1/views/all/list?query=${encodeURIComponent(debounced)}`}>
                Search in HubSpot
              </a>{" "}or{" "}
              <a className="underline-offset-2 hover:underline" target="_blank" rel="noreferrer" href="https://app.hubspot.com/contacts/23533734/objects/0-1/views/all/list">
                create the contact
              </a>, then paste its URL here.
            </div>
          ) : results.map((c) => (
            <div key={c.id} className="flex flex-wrap items-center gap-2 rounded border border-border/60 px-3 py-2 text-[13px]" data-testid={`row-contact-${c.id}`}>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="font-semibold">{c.name}</span>
                  <a href={c.link} target="_blank" rel="noreferrer" title="Open in HubSpot" className="text-muted-foreground hover:text-foreground"><ExternalLink className="h-3 w-3" /></a>
                  {holdsAlready(c) && <span className="rounded bg-[#71A8A3]/20 px-1 text-[10px] uppercase tracking-wide text-[#71A8A3]">has this serial</span>}
                  {hasLogin(c) && <span className="rounded bg-[#71A8A3]/20 px-1 text-[10px] uppercase tracking-wide text-[#71A8A3]">has this login</span>}
                </div>
                <div className="truncate text-xs text-muted-foreground">
                  {[c.email, c.phone, c.location, c.tractor].filter(Boolean).join(" · ") || "no email / phone on record"}
                </div>
                {(c.serials.length > 0 || c.logins.length > 0) && (
                  <div className="truncate font-mono text-[11px] text-muted-foreground">
                    {c.serials.length ? `${c.serials.length} serial${c.serials.length > 1 ? "s" : ""}: ${c.serials.slice(0, 3).join(", ")}${c.serials.length > 3 ? "…" : ""}` : "no serials"}
                    {c.logins.length ? ` · logins: ${c.logins.slice(0, 2).join(", ")}${c.logins.length > 2 ? "…" : ""}` : ""}
                  </div>
                )}
              </div>
              <Button size="sm" className="h-8 bg-[#71A8A3] text-black hover:bg-[#5f918c]" disabled={link.isPending}
                onClick={() => link.mutate(c.id)} data-testid={`button-link-${c.id}`}>
                {link.isPending && link.variables === c.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <UserPlus className="mr-1 h-3.5 w-3.5" />} Link
              </Button>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
