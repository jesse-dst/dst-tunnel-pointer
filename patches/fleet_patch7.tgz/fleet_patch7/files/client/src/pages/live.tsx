import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Play, Pause, RadarIcon, Plus, Trash2, CheckCheck, Check, BellRing, ExternalLink, Phone, Link2 } from "lucide-react";
import { ContactPicker } from "@/components/contact-picker";

type LiveState = {
  running: boolean; intervalS: number; watchScope: string; cycleActive: boolean;
  lastCycle: { ts: number; polled: number; ok: number; connected?: number; moving: number; tookMs: number; dmsOnline?: number | null; dmsTotal?: number | null } | null;
  sweep: { running: boolean; done: number; total: number };
  mapPush?: { enabled: boolean; url: string; tokenSet: boolean; last: { ts: number; ok: boolean; status: number | string; rigs: number } | null };
  watching: number; openAlerts: number;
};
type BoardRow = {
  sn: string; ts: number; is_online: number | null; work_status: number | null;
  lat: number | null; lng: number | null; speed_mph: number | null; heading: number | null;
  rtk_status: number | null; gps_work_status: number | null; satellites: number | null; moved: number;
  connected: number | null; conn_ts: number | null;
  net_mode: string | null; net_operator: string | null; net_rssi: number | null; net_ts: number | null;
  rig: { device_name: string; machine_class: string; model: string; customer_contact: string; customer_email: string; city: string; province: string } | null;
  customer: { customer_name: string; hubspot_link: string | null; address: string | null } | null;
  contact: { name: string | null; phone: string | null; hubspot_contact_link: string | null; hubspot_deal_link: string | null; source?: string | null; confidence?: string | null; evidence?: string | null } | null;
  open_alerts: number;
};

function netLabel(r: BoardRow): string | null {
  if (!r.net_mode) return null;
  const mode = r.net_mode.toUpperCase() === "WIFI" ? "WiFi" : r.net_mode;
  const op = r.net_operator ? ` · ${r.net_operator}` : "";
  const sig = r.net_rssi != null ? ` · sig ${r.net_rssi}` : "";
  return `${mode}${op}${sig}`;
}

function cloudTalkUrl(phone: string) {
  const normalized = (phone.trim().startsWith("+") ? "+" : "") + phone.replace(/[^\d]/g, "");
  return `https://dashboard.cloudtalk.io/menu/contacts/list?pageIndex=1&phoneNumber=${encodeURIComponent(normalized)}`;
}
type Rule = { id: number; name: string; field: string; op: string; value: number; value2: number | null; enabled: number; only_moving: number };
type ReviewCand = { id: string; name: string | null; score: number; reasons: string[]; link: string };
type ReviewRig = {
  sn: string; device_name: string | null; machine: string; login: string | null; dms_contact: string | null; location: string;
  activated: string | null; confidence: string; conflict: boolean; candidates: ReviewCand[];
  deal: { id: string; name: string; contacts: number; link: string } | null;
};
type MatchReview = {
  generated: string | null; tally: Record<string, number>; rigs?: number;
  unmatched: ReviewRig[]; needs_review: ReviewRig[]; internal?: ReviewRig[];
  transfers?: { sn: string; machine: string; to: { id: string; name: string | null; created: string }; from: { id: string; name: string | null; created: string }[] }[];
  shared_logins: { login: string; contacts: { id: string; name: string | null; holds_unit?: boolean; created?: string }[];
    dms_serials?: { sn: string; on_contacts: string[] }[] }[];
  hubspot_writes: { sn: string; contact: string | null; id: string; action: string; error?: string }[];
};
/** Confidence tag for a customer match that did not come from a hard serial link. */
function confidenceNote(c: BoardRow["contact"]): { label: string; title: string } | null {
  if (!c || !c.confidence || c.confidence === "high") return null;
  let title = "Matched by FJD login / other keys — confirm serial on the HubSpot contact";
  try { const ev = JSON.parse(c.evidence || "{}"); if (Array.isArray(ev.reasons)) title = `Matched via: ${ev.reasons.join(", ")} (score ${ev.score})`; } catch { /* keep default */ }
  return { label: c.confidence === "medium" ? "probable" : "guess", title };
}
type Ev = { id: number; rule_id: number; sn: string; ts: number; message: string; ack_ts: number | null; rule_name: string | null; rig: { device_name: string; customer_contact: string; city: string } | null };

function ago(ts: number | null): string {
  if (!ts) return "—";
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}

function statusOf(r: BoardRow): { label: string; color: string; live: boolean } {
  // "Live" means the terminal's connection flag (appConnState) was ON at the
  // last connection sweep — a direct DMS fact, not inferred from stale data.
  const connFresh = r.conn_ts != null && Date.now() - r.conn_ts < 30 * 60e3;
  const fresh = r.ts != null && Date.now() - r.ts < 30 * 60e3;
  if (r.connected === 1 && connFresh) {
    if (r.moved && fresh) return { label: "Moving", color: "#CE661F", live: true };
    return { label: "Live", color: "#71A8A3", live: true };
  }
  return { label: "Off", color: "#8a8578", live: false };
}

const OPS = [
  { v: "gt", l: ">" }, { v: "lt", l: "<" }, { v: "eq", l: "=" }, { v: "ne", l: "≠" }, { v: "between", l: "between" },
];

export default function LivePage() {
  const { toast } = useToast();
  const { data: state } = useQuery<LiveState>({ queryKey: ["/api/live/state"], refetchInterval: 10000 });
  const { data: board } = useQuery<BoardRow[]>({ queryKey: ["/api/live/board"], refetchInterval: 15000 });
  const { data: rules } = useQuery<Rule[]>({ queryKey: ["/api/live/rules"] });
  const { data: alerts } = useQuery<Ev[]>({ queryKey: ["/api/live/alerts"], refetchInterval: 15000 });
  const { data: review } = useQuery<MatchReview>({ queryKey: ["/api/live/match-review"], refetchInterval: 300000 });
  const [reviewOpen, setReviewOpen] = useState(false);
  // Manual "link this serial to a HubSpot contact" dialog (board rows + review lists).
  const [linkTarget, setLinkTarget] = useState<{ sn: string; login: string | null; query: string; current: { name: string | null; link: string | null; source?: string | null } | null } | null>(null);
  const { data: fields } = useQuery<{ key: string; label: string; unit: string | null }[]>({ queryKey: ["/api/live/fields"] });

  const config = useMutation({
    mutationFn: async (body: Record<string, unknown>) => (await apiRequest("POST", "/api/live/config", body)).json(),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/live/state"] }),
  });
  const sweep = useMutation({
    mutationFn: async () => (await apiRequest("POST", "/api/live/sweep", {})).json(),
    onSuccess: () => {
      toast({ title: "Full fleet sweep started", description: "Polling all rigs once — takes a few minutes." });
      queryClient.invalidateQueries({ queryKey: ["/api/live/state"] });
    },
  });

  // ---------------- map ----------------
  const mapRef = useRef<L.Map | null>(null);
  const layerRef = useRef<L.LayerGroup | null>(null);
  const mapDiv = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!mapDiv.current || mapRef.current) return;
    const map = L.map(mapDiv.current, { zoomControl: true, attributionControl: true }).setView([39.5, -95], 4);
    L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}", {
      attribution: "Tiles &copy; Esri", maxNativeZoom: 16, subdomains: "abcd", maxZoom: 19,
    }).addTo(map);
    layerRef.current = L.layerGroup().addTo(map);
    mapRef.current = map;
    return () => { map.remove(); mapRef.current = null; };
  }, []);

  useEffect(() => {
    const layer = layerRef.current;
    if (!layer || !board) return;
    layer.clearLayers();
    const pts: [number, number][] = [];
    for (const r of board) {
      if (r.lat == null || r.lng == null || (r.lat === 0 && r.lng === 0)) continue;
      const st = statusOf(r);
      const color = r.open_alerts > 0 ? "#B22C2B" : st.color;
      pts.push([r.lat, r.lng]);
      const m = L.circleMarker([r.lat, r.lng], {
        radius: r.moved ? 8 : st.live ? 6 : 4,
        color, fillColor: color,
        fillOpacity: st.live ? 0.9 : 0.35,
        weight: r.moved ? 2 : 1,
        opacity: st.live ? 1 : 0.5,
      });
      const note = confidenceNote(r.contact);
      const cust = (r.contact?.name ?? r.customer?.customer_name ?? r.rig?.customer_contact ?? "—") + (note ? ` <i title="${note.title.replace(/"/g, "&quot;")}">(${note.label})</i>` : "");
      const hsLink = r.contact?.hubspot_contact_link ?? r.contact?.hubspot_deal_link ?? r.customer?.hubspot_link;
      const phoneLine = r.contact?.phone
        ? `Phone: ${r.contact.phone} · <a href="${cloudTalkUrl(r.contact.phone)}" target="_blank">Call in CloudTalk</a><br/>`
        : "";
      m.bindPopup(
        `<div style="font-size:13px;min-width:200px">
          <b>${r.sn}</b><br/>${r.rig?.device_name ?? ""} · ${r.rig?.model ?? ""}<br/>
          Customer: ${cust}<br/>
          ${phoneLine}Speed: ${r.speed_mph ?? "—"} mph · Sats: ${r.satellites ?? "—"}${st.live ? " (as of last upload)" : " (last known)"}<br/>
          ${netLabel(r) ? `Network: ${netLabel(r)}<br/>` : ""}
          Status: ${st.label} · ${st.live ? `Data ${ago(r.ts)}` : `Last data ${ago(r.ts)}`}<br/>
          <a href="#/rig/${r.sn}">Open rig page</a>${hsLink ? ` · <a href="${hsLink}" target="_blank">HubSpot</a>` : ""}
        </div>`
      );
      m.addTo(layer);
    }
    if (pts.length && mapRef.current && !mapRef.current.getBounds().isValid()) {
      mapRef.current.fitBounds(L.latLngBounds(pts).pad(0.2));
    }
  }, [board]);

  const moving = useMemo(() => (board ?? []).filter((r) => statusOf(r).label === "Moving"), [board]);
  const liveNow = useMemo(() => (board ?? []).filter((r) => statusOf(r).live), [board]);
  const openAlerts = useMemo(() => (alerts ?? []).filter((a) => !a.ack_ts), [alerts]);

  // ---------------- rule dialog ----------------
  const [ruleOpen, setRuleOpen] = useState(false);
  const [rName, setRName] = useState("");
  const [rField, setRField] = useState("satellites");
  const [rOp, setROp] = useState("lt");
  const [rVal, setRVal] = useState("");
  const [rVal2, setRVal2] = useState("");
  const [rMoving, setRMoving] = useState(true);

  const createRule = useMutation({
    mutationFn: async () =>
      (
        await apiRequest("POST", "/api/live/rules", {
          name: rName || `${fields?.find((f) => f.key === rField)?.label} ${OPS.find((o) => o.v === rOp)?.l} ${rVal}`,
          field: rField, op: rOp, value: parseFloat(rVal), value2: rOp === "between" ? parseFloat(rVal2) : null,
          only_moving: rMoving,
        })
      ).json(),
    onSuccess: () => {
      setRuleOpen(false); setRName(""); setRVal(""); setRVal2("");
      queryClient.invalidateQueries({ queryKey: ["/api/live/rules"] });
      toast({ title: "Alert rule created" });
    },
  });
  const delRule = useMutation({
    mutationFn: async (id: number) => apiRequest("DELETE", `/api/live/rules/${id}`),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/live/rules"] }),
  });
  const toggleRule = useMutation({
    mutationFn: async ({ id, enabled }: { id: number; enabled: boolean }) => apiRequest("PATCH", `/api/live/rules/${id}`, { enabled }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/live/rules"] }),
  });
  const ack = useMutation({
    mutationFn: async (id: number) => apiRequest("POST", `/api/live/alerts/${id}/ack`, {}),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/live/alerts"] }),
  });
  const ackAll = useMutation({
    mutationFn: async () => apiRequest("POST", "/api/live/alerts/ack-all", {}),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/live/alerts"] }),
  });

  const fieldMeta = (k: string) => fields?.find((f) => f.key === k);

  // ---------------- per-rig alert drawer (click the red badge) ----------------
  const [alertSn, setAlertSn] = useState<string | null>(null);
  const rigAlerts = useMemo(() => (alerts ?? []).filter((a) => a.sn === alertSn), [alerts, alertSn]);
  const rigAlertsOpen = useMemo(() => rigAlerts.filter((a) => !a.ack_ts), [rigAlerts]);
  const alertRow = useMemo(() => (board ?? []).find((r) => r.sn === alertSn) ?? null, [board, alertSn]);
  const ackRig = useMutation({
    mutationFn: async (ids: number[]) => { for (const id of ids) await apiRequest("POST", `/api/live/alerts/${id}/ack`, {}); },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/live/alerts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/live/board"] });
      toast({ title: "Alerts acknowledged" });
    },
  });
  const ackOne = useMutation({
    mutationFn: async (id: number) => apiRequest("POST", `/api/live/alerts/${id}/ack`, {}),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/live/alerts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/live/board"] });
    },
  });

  return (
    <Layout title="Live Monitor">
      {linkTarget && (
        <ContactPicker
          sn={linkTarget.sn} open={true} onOpenChange={(o) => { if (!o) setLinkTarget(null); }}
          login={linkTarget.login} initialQuery={linkTarget.query} current={linkTarget.current}
        />
      )}
      <div className="space-y-4">
        {/* control bar */}
        <Card>
          <CardContent className="flex flex-wrap items-center gap-x-5 gap-y-3 p-4">
            <div className="flex items-center gap-2">
              <Switch
                checked={state?.running ?? false}
                onCheckedChange={(v) => config.mutate({ running: v })}
                data-testid="switch-poller"
              />
              <span className="text-sm font-semibold">{state?.running ? "Polling" : "Paused"}</span>
              {state?.cycleActive && <Badge variant="secondary" data-testid="badge-cycle">cycle running…</Badge>}
            </div>
            <div className="flex items-center gap-2 text-sm">
              <span className="text-muted-foreground">Every</span>
              <Select value={String(state?.intervalS ?? 180)} onValueChange={(v) => config.mutate({ intervalS: parseInt(v) })}>
                <SelectTrigger className="h-8 w-24" data-testid="select-interval"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="60">1 min</SelectItem>
                  <SelectItem value="120">2 min</SelectItem>
                  <SelectItem value="180">3 min</SelectItem>
                  <SelectItem value="300">5 min</SelectItem>
                  <SelectItem value="600">10 min</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <span className="text-muted-foreground">Checks connection flag fleet-wide, pulls details for live rigs only</span>
            </div>
            <Button
              size="sm" variant="outline" onClick={() => sweep.mutate()}
              disabled={state?.sweep.running}
              data-testid="button-sweep"
            >
              <RadarIcon className="mr-1.5 h-4 w-4" />
              {state?.sweep.running ? `Sweeping ${state.sweep.done}/${state.sweep.total}` : "Sweep whole fleet now"}
            </Button>
            <div className="text-xs text-muted-foreground" data-testid="text-last-cycle">
              {state?.lastCycle
                ? `Last cycle: checked ${state.lastCycle.polled} rigs · ${state.lastCycle.connected ?? "—"} live · ${state.lastCycle.moving} moving${state.lastCycle.dmsOnline != null ? ` · DMS fleet-wide: ${state.lastCycle.dmsOnline} online` : ""} · ${(state.lastCycle.tookMs / 1000).toFixed(0)}s · ${ago(state.lastCycle.ts)}`
                : "No cycle yet — flip the switch or run a sweep"}
            </div>
            {state?.mapPush?.enabled && (
              <div className="text-xs text-muted-foreground" data-testid="text-map-push">
                {state.mapPush.last
                  ? state.mapPush.last.ok
                    ? `Map push: ${state.mapPush.last.rigs} live rigs sent to DST Customer Map · ${ago(state.mapPush.last.ts)}`
                    : `Map push: waiting on map app endpoint (${state.mapPush.last.status}) · ${ago(state.mapPush.last.ts)}`
                  : "Map push: on — sends live rigs to DST Customer Map after each cycle"}
              </div>
            )}
          </CardContent>
        </Card>

        {/* KPIs */}
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <Card><CardContent className="p-4">
            <div className="text-2xl font-bold" style={{ color: "#71A8A3" }} data-testid="kpi-live">
              {liveNow.length}
              {state?.lastCycle?.dmsOnline != null && (
                <span className="ml-1 text-sm font-normal text-muted-foreground">/ {state.lastCycle.dmsOnline} DMS</span>
              )}
            </div>
            <div className="text-xs text-muted-foreground">AT2 terminals live · DMS counts all device types</div>
          </CardContent></Card>
          <Card><CardContent className="p-4">
            <div className="text-2xl font-bold" style={{ color: "#CE661F" }} data-testid="kpi-moving">{moving.length}</div>
            <div className="text-xs text-muted-foreground">Moving now</div>
          </CardContent></Card>
          <Card><CardContent className="p-4">
            <div className="text-2xl font-bold" data-testid="kpi-rules">{(rules ?? []).filter((r) => r.enabled).length}</div>
            <div className="text-xs text-muted-foreground">Active alert rules</div>
          </CardContent></Card>
          <Card><CardContent className="p-4">
            <div className="text-2xl font-bold" style={{ color: openAlerts.length ? "#B22C2B" : undefined }} data-testid="kpi-alerts">
              {openAlerts.length}
            </div>
            <div className="text-xs text-muted-foreground">Open alerts</div>
          </CardContent></Card>
        </div>

        {/* map */}
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm uppercase tracking-wide">Fleet map</CardTitle></CardHeader>
          <CardContent className="p-2">
            <div ref={mapDiv} className="relative z-0 h-[340px] w-full rounded-md md:h-[440px]" data-testid="map-live" />
            <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 px-2 text-xs text-muted-foreground">
              <span><span className="mr-1 inline-block h-2.5 w-2.5 rounded-full" style={{ background: "#CE661F" }} />Moving</span>
              <span><span className="mr-1 inline-block h-2.5 w-2.5 rounded-full" style={{ background: "#71A8A3" }} />Live (connected)</span>
              <span><span className="mr-1 inline-block h-2.5 w-2.5 rounded-full" style={{ background: "#8a8578" }} />Off · last known position</span>
              <span><span className="mr-1 inline-block h-2.5 w-2.5 rounded-full" style={{ background: "#B22C2B" }} />Open alert</span>
            </div>
          </CardContent>
        </Card>

        {/* alerts + rules */}
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm uppercase tracking-wide">Alert rules</CardTitle>
              <Dialog open={ruleOpen} onOpenChange={setRuleOpen}>
                <DialogTrigger asChild>
                  <Button size="sm" data-testid="button-add-rule"><Plus className="mr-1 h-4 w-4" />Add rule</Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader><DialogTitle>New alert rule</DialogTitle></DialogHeader>
                  <div className="space-y-3">
                    <Input placeholder="Rule name (optional)" value={rName} onChange={(e) => setRName(e.target.value)} data-testid="input-rule-name" />
                    <div className="grid grid-cols-2 gap-2">
                      <Select value={rField} onValueChange={setRField}>
                        <SelectTrigger data-testid="select-rule-field"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {(fields ?? []).map((f) => (
                            <SelectItem key={f.key} value={f.key}>{f.label}{f.unit ? ` (${f.unit})` : ""}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Select value={rOp} onValueChange={setROp}>
                        <SelectTrigger data-testid="select-rule-op"><SelectValue /></SelectTrigger>
                        <SelectContent>{OPS.map((o) => <SelectItem key={o.v} value={o.v}>{o.l}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <Input type="number" placeholder={`Value${fieldMeta(rField)?.unit ? ` (${fieldMeta(rField)?.unit})` : ""}`} value={rVal} onChange={(e) => setRVal(e.target.value)} data-testid="input-rule-value" />
                      {rOp === "between" && (
                        <Input type="number" placeholder="and" value={rVal2} onChange={(e) => setRVal2(e.target.value)} data-testid="input-rule-value2" />
                      )}
                    </div>
                    <label className="flex items-center gap-2 text-sm">
                      <Switch checked={rMoving} onCheckedChange={setRMoving} data-testid="switch-rule-moving" />
                      Only while rig is moving
                    </label>
                    <Button className="w-full" disabled={!rVal || createRule.isPending} onClick={() => createRule.mutate()} data-testid="button-save-rule">
                      Create rule
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent className="space-y-2">
              {(rules ?? []).length === 0 && (
                <p className="text-sm text-muted-foreground">
                  No rules yet. Example: Satellites &lt; 20 while moving, or Speed &gt; 25 mph.
                </p>
              )}
              {(rules ?? []).map((r) => (
                <div key={r.id} className="flex items-center justify-between gap-2 rounded-md border p-2" data-testid={`row-rule-${r.id}`}>
                  <div className="min-w-0">
                    <div className="truncate text-sm font-medium">{r.name}</div>
                    <div className="text-xs text-muted-foreground">
                      {fieldMeta(r.field)?.label ?? r.field} {OPS.find((o) => o.v === r.op)?.l} {r.value}
                      {r.op === "between" ? ` and ${r.value2}` : ""}{r.only_moving ? " · only moving" : ""}
                    </div>
                  </div>
                  <div className="flex shrink-0 items-center gap-1">
                    <Switch checked={!!r.enabled} onCheckedChange={(v) => toggleRule.mutate({ id: r.id, enabled: v })} data-testid={`switch-rule-${r.id}`} />
                    <Button variant="ghost" size="icon" onClick={() => delRule.mutate(r.id)} data-testid={`button-del-rule-${r.id}`}>
                      <Trash2 className="h-4 w-4 text-muted-foreground" />
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="flex items-center gap-2 text-sm uppercase tracking-wide">
                <BellRing className="h-4 w-4" style={{ color: openAlerts.length ? "#B22C2B" : undefined }} />
                Alerts
              </CardTitle>
              {openAlerts.length > 0 && (
                <Button size="sm" variant="outline" onClick={() => ackAll.mutate()} data-testid="button-ack-all">
                  <CheckCheck className="mr-1 h-4 w-4" />Ack all
                </Button>
              )}
            </CardHeader>
            <CardContent className="max-h-80 space-y-2 overflow-y-auto">
              {(alerts ?? []).length === 0 && <p className="text-sm text-muted-foreground">No alerts fired yet.</p>}
              {(alerts ?? []).map((a) => (
                <div key={a.id} className={`flex items-start justify-between gap-2 rounded-md border p-2 ${a.ack_ts ? "opacity-50" : ""}`} data-testid={`row-alert-${a.id}`}>
                  <div className="min-w-0 text-sm">
                    <div className="font-medium">{a.message}</div>
                    <div className="text-xs text-muted-foreground">
                      <Link href={`/rig/${a.sn}`}><a className="underline">{a.sn}</a></Link>
                      {a.rig?.customer_contact ? ` · ${a.rig.customer_contact}` : ""} · {ago(a.ts)}
                    </div>
                  </div>
                  {!a.ack_ts && (
                    <Button variant="ghost" size="icon" className="shrink-0" onClick={() => ack.mutate(a.id)} data-testid={`button-ack-${a.id}`}>
                      <Check className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* live table */}
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm uppercase tracking-wide">Live board</CardTitle></CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-[13px]" style={{ fontVariantNumeric: "tabular-nums lining-nums" }}>
                <thead>
                  <tr className="border-b bg-muted/40 text-left text-xs uppercase text-muted-foreground">
                    <th className="px-3 py-2">Status</th>
                    <th className="px-3 py-2">Serial</th>
                    <th className="px-3 py-2">Customer</th>
                    <th className="px-3 py-2">Device</th>
                    <th className="px-3 py-2 text-right">Speed (mph)</th>
                    <th className="px-3 py-2 text-right">Sats</th>
                    <th className="px-3 py-2 text-right">RTK</th>
                    <th className="px-3 py-2">Network</th>
                    <th className="px-3 py-2">Updated</th>
                    <th className="px-3 py-2 text-right">Alerts</th>
                  </tr>
                </thead>
                <tbody>
                  {(board ?? []).slice(0, 300).map((r) => {
                    const st = statusOf(r);
                    return (
                      <tr key={r.sn} className="border-b last:border-0 hover:bg-muted/30" data-testid={`row-live-${r.sn}`}>
                        <td className="px-3 py-1.5">
                          <span className="inline-flex items-center gap-1.5 text-xs font-medium">
                            <span className="h-2 w-2 rounded-full" style={{ background: r.open_alerts ? "#B22C2B" : st.color }} />
                            {st.label}
                          </span>
                        </td>
                        <td className="px-3 py-1.5 font-mono text-xs">
                          <Link href={`/rig/${r.sn}`}><a className="underline-offset-2 hover:underline">{r.sn}</a></Link>
                        </td>
                        <td className="max-w-48 truncate px-3 py-1.5">
                          {r.contact?.name ?? r.customer?.customer_name ?? r.rig?.customer_contact ?? "—"}
                          <button
                            type="button"
                            title={r.contact?.name ? "Change the HubSpot contact for this serial" : "Link this serial to a HubSpot contact"}
                            onClick={(e) => { e.stopPropagation(); setLinkTarget({ sn: r.sn, login: r.rig?.customer_email ?? null, query: "", current: r.contact ? { name: r.contact.name, link: r.contact.hubspot_contact_link ?? r.contact.hubspot_deal_link ?? null, source: r.contact.source ?? null } : null }); }}
                            className={`ml-1 inline-block align-middle ${r.contact?.name ? "text-muted-foreground/60 hover:text-foreground" : "text-[#CE661F] hover:text-foreground"}`}
                            data-testid={`button-link-${r.sn}`}
                          >
                            <Link2 className="h-3 w-3" />
                          </button>
                          {(() => { const n = confidenceNote(r.contact); return n ? (
                            <span title={n.title} className="ml-1 rounded border border-[#CE661F]/60 px-1 text-[10px] uppercase tracking-wide text-[#CE661F]" data-testid={`tag-confidence-${r.sn}`}>{n.label}</span>
                          ) : null; })()}
                          {(r.contact?.hubspot_contact_link ?? r.contact?.hubspot_deal_link ?? r.customer?.hubspot_link) && (
                            <a
                              href={(r.contact?.hubspot_contact_link ?? r.contact?.hubspot_deal_link ?? r.customer?.hubspot_link) as string}
                              target="_blank" rel="noreferrer" title="Open in HubSpot"
                              className="ml-1 inline-block align-middle text-muted-foreground hover:text-foreground"
                              data-testid={`link-hubspot-${r.sn}`}
                            >
                              <ExternalLink className="h-3 w-3" />
                            </a>
                          )}
                          {r.contact?.phone && (
                            <a
                              href={cloudTalkUrl(r.contact.phone)}
                              target="_blank" rel="noreferrer" title={`Call ${r.contact.phone} in CloudTalk`}
                              className="ml-1 inline-block align-middle text-muted-foreground hover:text-foreground"
                              data-testid={`link-cloudtalk-${r.sn}`}
                            >
                              <Phone className="h-3 w-3" />
                            </a>
                          )}
                        </td>
                        <td className="max-w-36 truncate px-3 py-1.5">{r.rig?.device_name ?? "—"}</td>
                        <td className={`px-3 py-1.5 text-right ${st.live ? "" : "text-muted-foreground/60"}`}>{r.speed_mph ?? "—"}</td>
                        <td className={`px-3 py-1.5 text-right ${st.live ? "" : "text-muted-foreground/60"}`}>{r.satellites ?? "—"}</td>
                        <td className={`px-3 py-1.5 text-right ${st.live ? "" : "text-muted-foreground/60"}`}>{r.rtk_status ?? "—"}</td>
                        <td className={`whitespace-nowrap px-3 py-1.5 text-xs ${st.live ? "" : "text-muted-foreground/60"}`}>{netLabel(r) ?? "—"}</td>
                        <td className="px-3 py-1.5 text-xs text-muted-foreground">{ago(r.ts)}</td>
                        <td className="px-3 py-1.5 text-right">
                          {r.open_alerts > 0 && (
                            <button
                              type="button"
                              onClick={() => setAlertSn(r.sn)}
                              title={`${r.open_alerts} open alert${r.open_alerts === 1 ? "" : "s"} — click to view`}
                              className="inline-flex items-center gap-1 rounded-full bg-[#B22C2B] px-2 py-0.5 text-xs font-semibold text-white hover:bg-[#8f2322] focus:outline-none focus:ring-2 focus:ring-[#B22C2B]/50"
                              data-testid={`button-alerts-${r.sn}`}
                            >
                              <BellRing className="h-3 w-3" />
                              {r.open_alerts}
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                  {(board ?? []).length === 0 && (
                    <tr><td colSpan={10} className="px-3 py-8 text-center text-sm text-muted-foreground">
                      No live data yet — start polling or run a fleet sweep.
                    </td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* per-rig alerts dialog */}
        <Dialog open={alertSn != null} onOpenChange={(o) => { if (!o) setAlertSn(null); }}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle className="flex flex-wrap items-center gap-2 text-base">
                <BellRing className="h-4 w-4" style={{ color: "#B22C2B" }} />
                <span>Alerts · <span className="font-mono">{alertSn}</span></span>
                {alertRow && (
                  <span className="text-sm font-normal text-muted-foreground">
                    {alertRow.contact?.name ?? alertRow.customer?.customer_name ?? alertRow.rig?.customer_contact ?? ""}
                    {alertRow.rig?.model ? ` · ${alertRow.rig.model}` : ""}
                  </span>
                )}
              </DialogTitle>
            </DialogHeader>
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
              <span>{rigAlertsOpen.length} open · condition is still true on the rig's latest data</span>
              <div className="flex items-center gap-2">
                {alertSn && (
                  <Link href={`/rig/${alertSn}`}><a className="underline">Open rig page</a></Link>
                )}
                {rigAlertsOpen.length > 0 && (
                  <Button size="sm" variant="outline" disabled={ackRig.isPending} onClick={() => ackRig.mutate(rigAlertsOpen.map((a) => a.id))} data-testid="button-ack-rig">
                    <CheckCheck className="mr-1 h-4 w-4" />Ack all for this rig
                  </Button>
                )}
              </div>
            </div>
            <div className="max-h-[60vh] space-y-2 overflow-y-auto">
              {rigAlerts.length === 0 && (
                <p className="text-sm text-muted-foreground">No open alerts on this rig right now — it may have just cleared. The badge refreshes within 15 s.</p>
              )}
              {rigAlerts.map((a) => (
                <div key={a.id} className={`flex items-start justify-between gap-2 rounded-md border p-2 ${a.ack_ts ? "opacity-50" : ""}`} data-testid={`row-rig-alert-${a.id}`}>
                  <div className="min-w-0 text-sm">
                    <div className="font-medium">{a.message}</div>
                    <div className="text-xs text-muted-foreground">{a.rule_name ?? "Rule"} · fired {ago(a.ts)}</div>
                  </div>
                  {!a.ack_ts && (
                    <Button variant="ghost" size="icon" className="shrink-0" title="Acknowledge" onClick={() => ackOne.mutate(a.id)} data-testid={`button-ack-rig-alert-${a.id}`}>
                      <Check className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </DialogContent>
        </Dialog>

        {/* customer matching review: who is running what, and what HubSpot is missing */}
        {review && (
          <Card>
            <CardHeader className="pb-2">
              <button
                type="button"
                onClick={() => setReviewOpen((v) => !v)}
                className="flex w-full flex-wrap items-center gap-2 text-left"
                data-testid="button-toggle-match-review"
              >
                <CardTitle className="text-sm uppercase tracking-wide">Customer matching</CardTitle>
                <span className="rounded-full bg-[#B22C2B] px-2 py-0.5 text-xs font-semibold text-white">{review.unmatched.length} no customer</span>
                <span className="rounded-full bg-[#CE661F] px-2 py-0.5 text-xs font-semibold text-white">{review.needs_review.length} to confirm</span>
                {review.shared_logins.length > 0 && (
                  <span className="rounded-full bg-muted px-2 py-0.5 text-xs font-semibold">{review.shared_logins.length} shared logins</span>
                )}
                {(review.internal?.length ?? 0) > 0 && (
                  <span className="rounded-full bg-muted px-2 py-0.5 text-xs font-semibold text-muted-foreground">{review.internal!.length} DST/FJD stock</span>
                )}
                <span className="ml-auto text-xs text-muted-foreground">
                  {review.generated ? `matched ${ago(Date.parse(review.generated))}` : "matcher has not run yet"} · {reviewOpen ? "hide" : "show"}
                </span>
              </button>
            </CardHeader>
            {reviewOpen && (
              <CardContent className="space-y-4 text-[13px]">
                <p className="text-xs text-muted-foreground">
                  Know who owns a rig? Hit <span className="font-semibold">Link</span> on its row, pick the HubSpot contact, done — it's written to HubSpot and the Live Map right away.
                  {" "}The login each serial actually uses (from the FJD DMS) is the anchor. Every rig is scored against HubSpot on serial, serial-deal
                  association, that DMS login vs. the contact's email and FJD Login Info, DMS contact email, location and tractor text. High-confidence
                  matches are written back to HubSpot automatically (serial added, FJD login added, deal attached). Serials on two contacts go to the
                  deal-associated or newest record (used-unit transfers). The rest land here — the fix is usually one field on the right contact.
                </p>
                {[
                  { title: "Running, no customer found", rows: review.unmatched, empty: "Every active rig has a customer." },
                  { title: "Probable — confirm in HubSpot", rows: review.needs_review, empty: "Nothing to confirm." },
                  { title: "DST / FJD stock, demo & bench units (internal login)", rows: review.internal ?? [], empty: "None." },
                ].filter((sec) => sec.rows.length > 0 || sec.title.startsWith("Running")).map((sec) => (
                  <div key={sec.title}>
                    <div className="mb-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">{sec.title} ({sec.rows.length})</div>
                    {sec.rows.length === 0 ? (
                      <div className="text-xs text-muted-foreground">{sec.empty}</div>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="w-full text-xs">
                          <thead>
                            <tr className="border-b text-left uppercase text-muted-foreground">
                              <th className="px-2 py-1">Serial</th><th className="px-2 py-1">Machine</th><th className="px-2 py-1">FJD login</th>
                              <th className="px-2 py-1">Location</th><th className="px-2 py-1">Best guess</th><th className="px-2 py-1">Deal</th><th className="px-2 py-1"></th>
                            </tr>
                          </thead>
                          <tbody>
                            {sec.rows.slice(0, 200).map((x) => (
                              <tr key={x.sn} className="border-b border-border/60 align-top" data-testid={`row-review-${x.sn}`}>
                                <td className="whitespace-nowrap px-2 py-1 font-mono"><Link href={`/rig/${x.sn}`}><a className="hover:underline">{x.sn}</a></Link></td>
                                <td className="px-2 py-1">{x.machine || x.device_name || "—"}</td>
                                <td className="px-2 py-1 font-mono">{x.login ?? "—"}{x.dms_contact ? <span className="block text-muted-foreground">{x.dms_contact}</span> : null}</td>
                                <td className="px-2 py-1">{x.location || "—"}{x.activated ? <span className="block text-muted-foreground">act. {x.activated}</span> : null}</td>
                                <td className="px-2 py-1">
                                  {x.candidates.length === 0 ? (
                                    <a className="underline-offset-2 hover:underline" target="_blank" rel="noreferrer"
                                      href={`https://app.hubspot.com/contacts/23533734/objects/0-1/views/all/list?query=${encodeURIComponent(x.login ?? x.sn)}`}>
                                      search HubSpot
                                    </a>
                                  ) : x.candidates.map((c) => (
                                    <div key={c.id} title={c.reasons.join(", ")}>
                                      <a href={c.link} target="_blank" rel="noreferrer" className="underline-offset-2 hover:underline">{c.name ?? c.id}</a>
                                      <span className="text-muted-foreground"> {c.score} · {c.reasons.join(", ")}</span>
                                    </div>
                                  ))}
                                  {x.conflict && <span className="text-[#B22C2B]">conflict — two contacts claim this rig</span>}
                                </td>
                                <td className="px-2 py-1">
                                  {x.deal ? (
                                    <a href={x.deal.link} target="_blank" rel="noreferrer" className="underline-offset-2 hover:underline">
                                      {x.deal.contacts === 0 ? "deal, no contact" : `deal (${x.deal.contacts})`}
                                    </a>
                                  ) : "no deal"}
                                </td>
                                <td className="whitespace-nowrap px-2 py-1">
                                  <Button size="sm" variant="outline" className="h-6 px-2 text-[11px]"
                                    onClick={() => setLinkTarget({ sn: x.sn, login: x.login ?? null, query: x.candidates[0]?.name ?? "", current: null })}
                                    data-testid={`button-link-review-${x.sn}`}>
                                    <Link2 className="mr-1 h-3 w-3" /> Link
                                  </Button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                ))}
                {(review.transfers?.length ?? 0) > 0 && (
                  <div>
                    <div className="mb-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Used-unit transfers ({review.transfers!.length}) — serial is on two contacts; the newer/deal record is treated as owner. Remove it from the old record.</div>
                    <div className="space-y-0.5 text-xs">
                      {review.transfers!.map((t) => (
                        <div key={t.sn}>
                          <Link href={`/rig/${t.sn}`}><a className="font-mono hover:underline">{t.sn}</a></Link> {t.machine ? <span className="text-muted-foreground">{t.machine} </span> : null}
                          → <a className="font-semibold underline-offset-2 hover:underline" target="_blank" rel="noreferrer" href={`https://app.hubspot.com/contacts/23533734/record/0-1/${t.to.id}`}>{t.to.name ?? t.to.id}</a>
                          <span className="text-muted-foreground"> ({t.to.created.slice(0, 7)})</span>, still on {t.from.map((f, i) => (
                            <span key={f.id}>{i > 0 ? ", " : ""}<a className="underline-offset-2 hover:underline" target="_blank" rel="noreferrer" href={`https://app.hubspot.com/contacts/23533734/record/0-1/${f.id}`}>{f.name ?? f.id}</a><span className="text-muted-foreground"> ({f.created.slice(0, 7)})</span></span>
                          ))}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {review.shared_logins.length > 0 && (
                  <div>
                    <div className="mb-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Shared FJD logins ({review.shared_logins.length}) — bold = holds a unit DMS runs under this login; grey = login listed but none of its units (pasted?)</div>
                    <div className="space-y-1 text-xs">
                      {review.shared_logins.map((sl) => (
                        <div key={sl.login}>
                          <span className="font-mono">{sl.login}</span>: {sl.contacts.map((c, i) => (
                            <span key={c.id} className={c.holds_unit === false ? "text-muted-foreground" : "font-semibold"}>{i > 0 ? ", " : " "}
                              <a className="underline-offset-2 hover:underline" target="_blank" rel="noreferrer" href={`https://app.hubspot.com/contacts/23533734/record/0-1/${c.id}`}>{c.name ?? c.id}</a>
                              {c.created ? <span className="font-normal text-muted-foreground"> ({c.created.slice(0, 7)})</span> : null}
                            </span>
                          ))}
                          {sl.dms_serials && sl.dms_serials.length > 0 && (
                            <div className="pl-3 text-muted-foreground">DMS units on this login: {sl.dms_serials.map((d, i) => (
                              <span key={d.sn}>{i > 0 ? " · " : ""}<Link href={`/rig/${d.sn}`}><a className="font-mono hover:underline">{d.sn.slice(-6)}</a></Link>{d.on_contacts.length ? ` → ${d.on_contacts.join(", ")}` : " → on nobody"}</span>
                            ))}</div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {review.hubspot_writes.length > 0 && (
                  <div>
                    <div className="mb-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Written to HubSpot on last run ({review.hubspot_writes.length})</div>
                    <div className="space-y-0.5 text-xs">
                      {review.hubspot_writes.slice(0, 100).map((w, i) => (
                        <div key={i} className={w.action === "FAILED" ? "text-[#B22C2B]" : ""}>
                          <span className="font-mono">{w.sn}</span> → <a className="underline-offset-2 hover:underline" target="_blank" rel="noreferrer" href={`https://app.hubspot.com/contacts/23533734/record/0-1/${w.id}`}>{w.contact ?? w.id}</a>: {w.action}{w.error ? ` (${w.error})` : ""}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            )}
          </Card>
        )}

        <p className="text-xs text-muted-foreground">
          "Live" = the rig's terminal connection flag is ON right now (checked fleet-wide each cycle) — the only trustworthy DMS
          online signal. Speed/sats/RTK on live rigs are as of the rig's last upload this session (can lag by minutes — DMS has no
          timestamp on status data); grayed values on Off rigs are last-known from before shutdown. The DMS fleet-wide online count
          includes AT1/AS2/AG1 and other device types that have no per-serial online API. Speed converted from meters/second; unit
          pending engineer confirmation.
        </p>
      </div>
    </Layout>
  );
}
