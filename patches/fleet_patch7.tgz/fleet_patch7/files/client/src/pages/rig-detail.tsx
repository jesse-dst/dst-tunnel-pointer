import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { useEffect, useState } from "react";
import { ContactPicker } from "@/components/contact-picker";
import { ArrowLeft, ChevronDown, ChevronRight, BookOpenCheck } from "lucide-react";
import { Layout } from "@/components/layout";
import { DataTable, Skeleton } from "@/components/data-table";
import { WalkingLogs } from "@/components/walking-logs";
import { acres, num, feet, dateTime, daysAgo, dateShort } from "@/lib/format";
import { ExternalLink } from "lucide-react";

// snake_case fields from calibration DB → camelCase param field they map to.
const CONFIG_TO_PARAM: Record<string, string> = {
  steering_wheel: "steeringWheel",
  valve_type: "valveType",
  angle_sensor_type: "angleSensorType",
  control_model: "controlModel",
  rtk_mode: "rtkMode",
};
type ParamLabel = { field: string; label: string; unit: string | null; enumMap: Record<string, string> | null; catalogUnit?: string | null; category: string; hidden: boolean; description: string | null };
type RigParamsResponse = {
  sn: string;
  fetched_ts: number | null;
  data: Record<string, { value: unknown; unit: string | null }> | null;
  raw: Record<string, unknown> | null;
  history: { ts: number; field: string; old_value: string | null; new_value: string | null }[];
};

// Category header labels. Order comes from saved sort_order (first field wins).
const CATEGORY_LABEL: Record<string, string> = {
  steering: "Steering & aggressiveness",
  model: "Model settings",
  gps: "GPS & antenna",
  motor: "Motor & steering wheel",
  geometry: "Geometry & implement",
  turn: "Turn / headland",
  alarms: "Alarms",
  other: "Other",
};

interface RigDetail {
  rig: Record<string, unknown>;
  hubspot?: { name: string | null; email: string | null; phone: string | null; link: string | null; source?: string | null; confidence?: string | null };
  hubspotLinkConfigured?: boolean;
  config?: Record<string, unknown>;
  configAll: Record<string, unknown>;
  version?: Record<string, unknown>;
  sessions: Record<string, unknown>[];
  history: Record<string, unknown>[];
  gpsCount: number;
  endpoints: Record<string, unknown>[];
}
interface PeerStats {
  peerGroup: string;
  stats: Record<string, { min: number; max: number; avg: number; n: number; mine: number | null }>;
}

/** Seed the contact search from what we know: the DMS contact email if it's not masked, else nothing. */
function loginGuess(login: string | null, dmsContact: string | null): string {
  const c = (dmsContact ?? "").trim();
  if (c.includes("@") && !c.includes("*")) return c;
  const l = (login ?? "").trim();
  if (l.includes("@") && !l.includes("*") && !/^dst\d+@/i.test(l) && !/@(deepsandtech|fjdynamics|pargps)\./i.test(l)) return l;
  return "";
}

function Field({ label, value, testId }: { label: string; value: unknown; testId?: string }) {
  return (
    <div>
      <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="truncate text-[13px]" data-testid={testId} title={String(value ?? "")}>
        {value === null || value === undefined || value === "" ? "—" : String(value)}
      </div>
    </div>
  );
}

// Sanity ranges for live DMS values (already converted to imperial by server).
// Values outside these ranges are almost certainly test/garbage data — flag them.
// Enum fields are excluded (steeringWheel, valveType, angleSensorType, controlModel, rtkMode, modelSelection).
const SANITY_RANGES: Record<string, { min: number; max: number; unit: string }> = {
  workWidth:         { min: 3,     max: 60,    unit: "ft" },
  toolsWorkWidth:    { min: 0,     max: 60,    unit: "ft" },
  toolOffset:        { min: -20,   max: 20,    unit: "ft" },
  turningRadius:     { min: 3,     max: 80,    unit: "ft" },
  gpsHigh:           { min: 3,     max: 20,    unit: "ft" },
  gpsRearCenter:     { min: -10,   max: 30,    unit: "ft" },
  gpsCenterDistance: { min: -5,    max: 5,     unit: "ft" },
  frontAxle:         { min: 0,     max: 20,    unit: "ft" },
  frontWheelWidth:   { min: 3,     max: 15,    unit: "ft" },
  rearAxlePoint:     { min: 0,     max: 20,    unit: "ft" },
  aroundDistance:    { min: 0,     max: 60,    unit: "ft" },
  lineSpacing:       { min: 0,     max: 10,    unit: "ft" },
  transmissionRatio: { min: 0.5,   max: 40,    unit: ""   },
  angleMidVoltage:   { min: 0,     max: 5,     unit: "V"  },
  angleLeftVoltage:  { min: 0,     max: 5,     unit: "V"  },
  angleRightVoltage: { min: 0,     max: 5,     unit: "V"  },
};

function sanityCheck(field: string, rawValue: unknown): { ok: boolean; reason?: string } {
  const spec = SANITY_RANGES[field];
  if (!spec) return { ok: true };
  const n = typeof rawValue === "number" ? rawValue : Number(String(rawValue).replace(/[^\d.\-]/g, ""));
  if (!Number.isFinite(n)) return { ok: true };
  const u = spec.unit ? " " + spec.unit : "";
  if (n < spec.min) return { ok: false, reason: `< ${spec.min}${u}` };
  if (n > spec.max) return { ok: false, reason: `> ${spec.max}${u}` };
  return { ok: true };
}

// "Approve setup" — snapshot this rig's current DMS params into the approved
// setups library (used by the Support Center's Suggested Setup tab).
function ApproveSetupButton({ sn }: { sn: string }) {
  const [state, setState] = useState<"idle" | "busy" | "done" | "error">("idle");
  const [msg, setMsg] = useState("");
  const approve = async () => {
    const note = window.prompt("Approve this rig's current parameters as a known-good setup?\n\nOptional note (what makes this setup good, implement, conditions):");
    if (note === null) return; // cancelled
    const approvedBy = window.prompt("Your name (shown as approver):") ?? "";
    setState("busy");
    try {
      const { apiRequest } = await import("@/lib/queryClient");
      await apiRequest("POST", `/api/rig/${sn}/approve-setup`, { note: note || undefined, approvedBy: approvedBy || undefined });
      setState("done");
      setMsg("Added to the approved setups library");
    } catch (e: any) {
      setState("error");
      setMsg(String(e?.message ?? e));
    }
  };
  return (
    <div className="flex items-center gap-2">
      {msg && <span className={`text-[11px] ${state === "error" ? "text-red-600" : "text-muted-foreground"}`}>{msg}</span>}
      <button
        onClick={approve}
        disabled={state === "busy"}
        className="inline-flex items-center gap-1.5 rounded-md border bg-card px-2.5 py-1.5 text-xs font-medium hover:bg-accent disabled:opacity-50"
        data-testid="button-approve-setup"
        title="Snapshot this rig's current parameters as an approved setup"
      >
        <BookOpenCheck className="h-3.5 w-3.5" />
        {state === "done" ? "Setup approved ✓" : state === "busy" ? "Approving…" : "Approve setup"}
      </button>
    </div>
  );
}

// Render a single field from the live DMS params dict. Respects admin label + enum remap.
function LiveParamField({ field, params, labels, testId }: { field: string; params: Record<string, { value: unknown; unit: string | null }>; labels: ParamLabel[] | undefined; testId?: string }) {
  const meta = labels?.find((p) => p.field === field);
  const label = meta?.label ?? field;
  const cell = params[field];
  let display: string;
  let sanity: { ok: boolean; reason?: string } = { ok: true };
  if (!cell || cell.value == null || cell.value === "") {
    display = "—";
  } else {
    const raw = String(cell.value);
    const remapped = meta?.enumMap?.[raw];
    display = remapped ?? raw;
    if (cell.unit && !remapped) display = `${display} ${cell.unit}`;
    if (!remapped) sanity = sanityCheck(field, cell.value);
  }
  return (
    <div>
      <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className={`truncate text-[13px] ${sanity.ok ? "" : "text-red-600 font-medium"}`} data-testid={testId} title={sanity.ok ? String(display) : `Out of plausible range (${sanity.reason})`}>
        {display}
        {!sanity.ok && <span className="ml-1.5 inline-block rounded bg-red-100 px-1 text-[10px] font-semibold text-red-700" data-testid={`sanity-warn-${field}`}>⚠ {sanity.reason}</span>}
      </div>
    </div>
  );
}

// Same, but reads from a raw vp_library profile record (no imperial pre-conversion, keys already camelCase).
function ProfileParamField({ field, data, labels }: { field: string; data: Record<string, unknown> | null | undefined; labels: ParamLabel[] | undefined }) {
  const meta = labels?.find((p) => p.field === field);
  const label = meta?.label ?? field;
  const raw = data?.[field];
  let display: string;
  if (raw == null || raw === "") {
    display = "—";
  } else {
    const rs = String(raw);
    const remapped = meta?.enumMap?.[rs];
    display = remapped ?? rs;
  }
  return <Field label={label} value={display} />;
}

function Section({ title, children, defaultOpen = true }: { title: string; children: React.ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="rounded-lg border bg-card">
      <button
        onClick={() => setOpen((o) => !o)}
        data-testid={`button-section-${title.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`}
        className="flex w-full items-center gap-1.5 px-4 py-2.5 text-left text-[11px] font-semibold uppercase tracking-wide text-muted-foreground"
      >
        {open ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
        {title}
      </button>
      {open && <div className="border-t px-4 py-3">{children}</div>}
    </div>
  );
}

export default function RigDetail() {
  const [, params] = useRoute("/rig/:sn");
  const sn = params?.sn ?? "";
  const { data, isLoading } = useQuery<RigDetail>({ queryKey: ["/api/rig", sn] });
  // "Link HubSpot contact" dialog. Auto-opens when the page is reached with
  // ?link=1 (the Live Map's "Link HubSpot contact" button lands here).
  const [linkOpen, setLinkOpen] = useState(false);
  useEffect(() => {
    const wantsLink = /[?&]link=1/.test(window.location.search) || /[?&]link=1/.test(window.location.hash);
    if (wantsLink && sn) setLinkOpen(true);
  }, [sn]);
  const { data: peers } = useQuery<PeerStats>({ queryKey: ["/api/rig", sn, "peers"] });
  const { data: paramLabels } = useQuery<ParamLabel[]>({ queryKey: ["/api/params/labels"], staleTime: 60_000, refetchOnWindowFocus: true });
  const { data: rigParams } = useQuery<RigParamsResponse>({
    queryKey: ["/api/rig", sn, "params"],
    queryFn: async () => {
      const { apiRequest } = await import("@/lib/queryClient");
      const r = await apiRequest("GET", `/api/rig/${sn}/params`);
      return r.json();
    },
  });

  // Vehicle Profile Library — currently assigned tractor + history
  type VpCurrent = { sn: string; fetched_ts: number | null; current: { id: number; brand: string | null; model: string | null; last_modify_ts: number | null; upload_ts: number | null; data: any } | null };
  type VpChange = { field: string; from: string; to: string };
  type VpHistory = { sn: string; fetched_ts: number | null; dedup?: boolean; profiles: Array<{ id: number; brand: string | null; model: string | null; last_modify_ts: number | null; upload_ts: number | null; is_current: boolean; changes?: VpChange[] }> };
  const { data: vpCurrent } = useQuery<VpCurrent>({
    queryKey: ["/api/rig", sn, "vp", "current"],
    queryFn: async () => {
      const { apiRequest } = await import("@/lib/queryClient");
      const r = await apiRequest("GET", `/api/rig/${sn}/vp/current`);
      return r.json();
    },
  });
  const { data: vpHistory } = useQuery<VpHistory>({
    queryKey: ["/api/rig", sn, "vp", "history"],
    queryFn: async () => {
      const { apiRequest } = await import("@/lib/queryClient");
      const r = await apiRequest("GET", `/api/rig/${sn}/vp/history`);
      return r.json();
    },
  });
  const [selectedProfileId, setSelectedProfileId] = useState<number | null>(null);
  const { data: selectedProfile } = useQuery<{ id: number; brand: string | null; model: string | null; last_modify_ts: number | null; data: any }>({
    queryKey: ["/api/vp", selectedProfileId],
    queryFn: async () => {
      const { apiRequest } = await import("@/lib/queryClient");
      const r = await apiRequest("GET", `/api/vp/${selectedProfileId}`);
      return r.json();
    },
    enabled: selectedProfileId != null,
  });

  // Look up admin-edited enum display for a config field. Falls back to raw value.
  const remap = (configField: string, rawVal: unknown): string => {
    if (rawVal == null || rawVal === "") return "—";
    const paramKey = CONFIG_TO_PARAM[configField];
    if (!paramKey || !paramLabels) return String(rawVal);
    const meta = paramLabels.find((p) => p.field === paramKey);
    if (!meta?.enumMap) return String(rawVal);
    return meta.enumMap[String(rawVal)] ?? String(rawVal);
  };

  if (isLoading || !data) {
    return (
      <Layout title={sn}>
        <Skeleton rows={12} />
      </Layout>
    );
  }

  const { rig, config, configAll, version, sessions, history, gpsCount, endpoints } = data;

  const sessionRows = sessions.map((s) => ({
    started: dateTime(s.create_time as string),
    ended: s.end_time ? dateTime(s.end_time as string) : "(not closed)",
    hours: s.work_time,
    acres: s.app_calc_area ? Number(acres(s.app_calc_area as number).replace(/,/g, "")) : null,
    rms: s.rms,
    fixed_pct: s.fixed_rate,
    location: [s.address, s.province].filter(Boolean).join(", "),
    work_no: s.work_no,
  }));

  // Fields stored in meters — convert to feet for display. Voltages, currents,
  // and ratios are not metric lengths and stay as-is.
  const METER_FIELDS: Record<string, string> = {
    work_width: "work width (ft)",
    tool_offset: "tool offset (ft)",
    gps_high: "gps height (ft)",
    turning_radius: "turning radius (ft)",
  };
  const M_TO_FT = 3.28084;
  const peerRows = peers
    ? Object.entries(peers.stats)
        .filter(([, v]) => v.n > 0)
        .map(([field, v]) => {
          const isMeters = field in METER_FIELDS;
          const cv = (x: number | null) => (x === null || x === undefined ? null : isMeters ? Number((x * M_TO_FT).toFixed(2)) : Number(Number(x).toFixed(3)));
          return {
            parameter: isMeters ? METER_FIELDS[field] : field.replace(/_/g, " "),
            this_rig: cv(v.mine),
            fleet_avg: cv(v.avg),
            fleet_min: cv(v.min),
            fleet_max: cv(v.max),
            rigs_reporting: v.n,
          };
        })
    : [];

  return (
    <Layout title={sn}>
      <div className="space-y-4">
        <div className="flex items-center justify-between gap-2">
          <Link href="/rigs">
            <a className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground" data-testid="link-back-rigs">
              <ArrowLeft className="h-3.5 w-3.5" /> All rigs
            </a>
          </Link>
          <ApproveSetupButton sn={sn} />
        </div>

        <div className="grid grid-cols-4 gap-x-4 gap-y-3 rounded-lg border bg-card p-4 max-lg:grid-cols-3 max-sm:grid-cols-2">
          <Field label="Device" value={rig.device_name} testId="text-device" />
          <Field label="Machine class" value={rig.machine_class} />
          <Field label="Brand" value={rig.brand_normalized || rig.brand_raw} />
          <Field label="Model" value={rig.model} />
          <div>
            <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Customer</div>
            <div className="flex items-center gap-1.5 text-[13px]" data-testid="text-customer" title={data.hubspot?.name ?? ""}>
              <span className="truncate">
                {data.hubspot?.name ? (
                  data.hubspot.link ? (
                    <a href={data.hubspot.link} target="_blank" rel="noreferrer" className="text-primary hover:underline" data-testid="link-hubspot">
                      {data.hubspot.name}
                    </a>
                  ) : (
                    data.hubspot.name
                  )
                ) : (
                  <span className="text-[#CE661F]">no HubSpot contact</span>
                )}
              </span>
              {data.hubspot?.source?.startsWith("manual") && (
                <span title={`Linked by hand (${data.hubspot.source})`} className="shrink-0 rounded border border-[#71A8A3]/60 px-1 text-[10px] uppercase tracking-wide text-[#71A8A3]">manual</span>
              )}
              {data.hubspot?.confidence && data.hubspot.confidence !== "high" && data.hubspot.confidence !== "manual" && (
                <span title="Auto-matched on FJD login / other keys — confirm" className="shrink-0 rounded border border-[#CE661F]/60 px-1 text-[10px] uppercase tracking-wide text-[#CE661F]">{data.hubspot.confidence === "medium" ? "probable" : data.hubspot.confidence}</span>
              )}
              <button
                type="button"
                onClick={() => setLinkOpen(true)}
                className="shrink-0 rounded border border-border px-1.5 py-0.5 text-[11px] text-muted-foreground hover:border-[#71A8A3] hover:text-foreground"
                data-testid="button-link-contact"
                title="Link this serial to a HubSpot contact"
              >
                {data.hubspot?.name ? "Change" : "Link"}
              </button>
            </div>
            <ContactPicker
              sn={sn} open={linkOpen} onOpenChange={setLinkOpen}
              login={rig.customer_email as string | null}
              initialQuery={data.hubspot?.name ? "" : loginGuess(rig.customer_email as string | null, rig.customer_contact as string | null)}
              current={data.hubspot ? { name: data.hubspot.name, link: data.hubspot.link, source: data.hubspot.source ?? null } : null}
            />
          </div>
          <Field label="Customer phone" value={data.hubspot?.phone} />
          <Field label="DMS email" value={rig.customer_email} testId="text-dms-email" />
          <Field label="DMS contact" value={rig.customer_contact} />
          <Field label="Location" value={[rig.city, rig.province].filter(Boolean).join(", ")} />
          <Field label="Activated" value={dateShort(rig.activation_date as string)} />
          <Field label="Last session" value={`${daysAgo(rig.last_session_time as string)}`} />
          <Field label="Lifetime sessions" value={rig.total_sessions} />
          <Field label="App conn (at pull)" value={rig.app_conn_state} />
          <Field label="Firmware" value={version?.app_version} />
          <Field label="ECU" value={version?.ecu_version} />
          <Field label="Subscription" value={rig.lock_status === 2 ? "Locked (active)" : rig.lock_status === 1 ? "Unlocked" : rig.lock_status} />
          <Field label="GPS points (12hr)" value={gpsCount} />
          <Field label="Factory no" value={rig.factory_no} />
        </div>

        {/* Current tractor (from FJD Vehicle Profile Library / Vehicle Info Repo) */}
        {vpCurrent?.current && (
          <div className="rounded-lg border bg-card p-4" data-testid="section-current-tractor">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                  Current tractor (Vehicle Profile Library)
                </div>
                <div className="mt-1 text-sm" data-testid="text-current-tractor">
                  {(() => {
                    const b = vpCurrent.current.brand?.trim();
                    const m = vpCurrent.current.model?.trim();
                    const label = [b, m].filter(Boolean).join(" ");
                    return label ? label : <span className="text-muted-foreground">— unnamed profile —</span>;
                  })()}
                  <span className="ml-2 text-xs text-muted-foreground">
                    profile #{vpCurrent.current.id}
                    {vpCurrent.current.last_modify_ts && ` · saved ${daysAgo(new Date(vpCurrent.current.last_modify_ts).toISOString())}`}
                  </span>
                </div>
              </div>
              <a
                href={`https://dms.fjdac.com/vehicleInfoRepository?vehicleSn=${sn}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                data-testid="link-open-in-dms"
              >
                Open in DMS <ExternalLink className="h-3 w-3" />
              </a>
            </div>
          </div>
        )}

        {/* Live steering & geometry — pulled from live DMS params (not stale walkscan). */}
        {rigParams?.raw && (
          <Section title="Steering & geometry config (live)">
            <div className="grid grid-cols-4 gap-x-4 gap-y-3 max-lg:grid-cols-3 max-sm:grid-cols-2">
              <LiveParamField field="steeringWheel" params={rigParams.data ?? {}} labels={paramLabels} />
              <LiveParamField field="valveType" params={rigParams.data ?? {}} labels={paramLabels} />
              <LiveParamField field="angleSensorType" params={rigParams.data ?? {}} labels={paramLabels} />
              <LiveParamField field="controlModel" params={rigParams.data ?? {}} labels={paramLabels} testId="field-control-model" />
              <LiveParamField field="workWidth" params={rigParams.data ?? {}} labels={paramLabels} />
              <LiveParamField field="toolOffset" params={rigParams.data ?? {}} labels={paramLabels} />
              <LiveParamField field="gpsHigh" params={rigParams.data ?? {}} labels={paramLabels} />
              <LiveParamField field="turningRadius" params={rigParams.data ?? {}} labels={paramLabels} />
              <LiveParamField field="angleMidVoltage" params={rigParams.data ?? {}} labels={paramLabels} />
              <LiveParamField field="angleLeftVoltage" params={rigParams.data ?? {}} labels={paramLabels} />
              <LiveParamField field="angleRightVoltage" params={rigParams.data ?? {}} labels={paramLabels} />
              <LiveParamField field="rtkMode" params={rigParams.data ?? {}} labels={paramLabels} />
            </div>
            {rigParams.fetched_ts && (
              <div className="mt-2 text-[10px] text-muted-foreground">Live values pulled {daysAgo(new Date(rigParams.fetched_ts).toISOString())}</div>
            )}
          </Section>
        )}

        {/* Profile history — like DMS change record. Read-only. */}
        {vpHistory && vpHistory.profiles.length > 0 && (
          <Section
            title={`Config history · ${vpHistory.profiles.length} change${vpHistory.profiles.length === 1 ? "" : "s"}${vpHistory.dedup ? " (deduped)" : ""}`}
            defaultOpen={false}
          >
            <div className="mb-2 text-[11px] text-muted-foreground">
              Each row is a saved profile where at least one tracked field changed vs the prior save. Same-value saves are hidden.
            </div>
            <div className="mb-3 flex flex-wrap items-center gap-2 text-xs">
              <span className="text-muted-foreground">View a saved profile:</span>
              <select
                className="rounded border bg-background px-2 py-1 text-xs"
                value={selectedProfileId ?? ""}
                onChange={(e) => setSelectedProfileId(e.target.value ? Number(e.target.value) : null)}
                data-testid="select-vp-profile"
              >
                <option value="">— pick a profile —</option>
                {vpHistory.profiles.map((p) => {
                  const b = p.brand?.trim();
                  const m = p.model?.trim();
                  const nameLabel = [b, m].filter(Boolean).join(" ") || `profile #${p.id}`;
                  const when = p.last_modify_ts ? ` • ${dateShort(new Date(p.last_modify_ts).toISOString())}` : "";
                  const cur = p.is_current ? " ★ current" : "";
                  const nchg = p.changes?.length ?? 0;
                  const chg = nchg > 0 ? ` • ${nchg} change${nchg === 1 ? "" : "s"}` : "";
                  return (
                    <option key={p.id} value={p.id}>
                      {nameLabel}{when}{chg}{cur}
                    </option>
                  );
                })}
              </select>
            </div>

            {/* Compact change log — what changed on each save vs the prior one. */}
            <div className="mb-3 max-h-64 overflow-y-auto rounded border bg-muted/20 text-[11px]">
              <table className="w-full">
                <thead className="sticky top-0 bg-muted/60 text-left">
                  <tr>
                    <th className="px-2 py-1 font-semibold">When</th>
                    <th className="px-2 py-1 font-semibold">Changes vs prior save</th>
                    <th className="px-2 py-1 font-semibold">Profile</th>
                  </tr>
                </thead>
                <tbody>
                  {vpHistory.profiles.map((p) => (
                    <tr
                      key={p.id}
                      className={`border-t hover:bg-muted/40 cursor-pointer ${selectedProfileId === p.id ? "bg-muted/50" : ""}`}
                      onClick={() => setSelectedProfileId(p.id)}
                    >
                      <td className="whitespace-nowrap px-2 py-1 align-top text-muted-foreground">
                        {p.last_modify_ts ? dateShort(new Date(p.last_modify_ts).toISOString()) : "—"}
                      </td>
                      <td className="px-2 py-1 align-top">
                        {p.changes && p.changes.length > 0 ? (
                          <div className="flex flex-wrap gap-1">
                            {p.changes.slice(0, 6).map((c, i) => (
                              <span key={i} className="rounded bg-background px-1.5 py-0.5">
                                <span className="font-medium">{c.field}</span>: {c.from} → {c.to}
                              </span>
                            ))}
                            {p.changes.length > 6 && (
                              <span className="text-muted-foreground">+{p.changes.length - 6} more</span>
                            )}
                          </div>
                        ) : (
                          <span className="text-muted-foreground">baseline (oldest saved)</span>
                        )}
                      </td>
                      <td className="whitespace-nowrap px-2 py-1 align-top">
                        #{p.id}{p.is_current && <span className="ml-1 text-amber-600">★</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {selectedProfile && (
              <div className="grid grid-cols-4 gap-x-4 gap-y-3 rounded border bg-muted/30 p-3 max-lg:grid-cols-3 max-sm:grid-cols-2">
                {["workWidth","toolOffset","gpsHigh","turningRadius","angleMidVoltage","angleLeftVoltage","angleRightVoltage","rtkMode","lateralSensitivity","headingSensitivity","steeringSensitivity","lineSpacing","transmissionRatio","toolsWorkWidth","gpsRearCenter"].map((f) => (
                  <ProfileParamField key={f} field={f} data={selectedProfile.data} labels={paramLabels} />
                ))}
              </div>
            )}
          </Section>
        )}

        {config && (
          <Section title="Walkscan snapshot (may be older than live)" defaultOpen={false}>
            <div className="grid grid-cols-4 gap-x-4 gap-y-3 max-lg:grid-cols-3 max-sm:grid-cols-2">
              <Field label={paramLabels?.find(p => p.field === "steeringWheel")?.label ?? "steeringWheel"} value={remap("steering_wheel", config.steering_wheel)} />
              <Field label={paramLabels?.find(p => p.field === "valveType")?.label ?? "valveType"} value={remap("valve_type", config.valve_type)} />
              <Field label={paramLabels?.find(p => p.field === "angleSensorType")?.label ?? "angleSensorType"} value={remap("angle_sensor_type", config.angle_sensor_type)} />
              <Field label={paramLabels?.find(p => p.field === "controlModel")?.label ?? "controlModel"} value={remap("control_model", config.control_model)} />
              <Field label="Work width" value={feet(config.work_width as number, 1)} />
              <Field label="Tool offset" value={feet(config.tool_offset as number, 2)} />
              <Field label="GPS height" value={feet(config.gps_high as number, 1)} />
              <Field label="Turning radius" value={feet(config.turning_radius as number, 1)} />
              <Field label="Angle mid V" value={num(config.angle_mid_voltage as number, 3)} />
              <Field label="Angle left V" value={num(config.angle_left_voltage as number, 3)} />
              <Field label="Angle right V" value={num(config.angle_right_voltage as number, 3)} />
              <Field label={paramLabels?.find(p => p.field === "rtkMode")?.label ?? "RTK mode"} value={remap("rtk_mode", config.rtk_mode)} />
            </div>
          </Section>
        )}

        {paramLabels && rigParams?.data && (
          <DmsParamsSection labels={paramLabels} values={rigParams.data} fetchedTs={rigParams.fetched_ts} />
        )}

        {peerRows.length > 0 && (
          <Section title={`Peer comparison — all ${peers?.peerGroup} rigs`}>
            <DataTable rows={peerRows} />
          </Section>
        )}

        <Section title="Walking logs — per-tick ECU telemetry">
          <WalkingLogs sn={sn} />
        </Section>

        <Section title={`Work sessions (${sessions.length} most recent)`}>
          <DataTable rows={sessionRows} maxHeight="24rem" />
        </Section>

        <Section title={`Calibration / param history (${history.length})`} defaultOpen={false}>
          <DataTable rows={history} maxHeight="24rem" />
        </Section>

        <Section title={`All config fields (${Object.keys(configAll).length}) — raw values as reported (metric)`} defaultOpen={false}>
          <div className="grid grid-cols-4 gap-x-4 gap-y-2 max-lg:grid-cols-3 max-sm:grid-cols-2">
            {Object.entries(configAll).map(([k, v]) => (
              <Field key={k} label={k} value={typeof v === "object" ? JSON.stringify(v) : v} />
            ))}
          </div>
        </Section>

        <Section title="Data pull audit" defaultOpen={false}>
          <DataTable rows={endpoints} />
        </Section>
      </div>
    </Layout>
  );
}

function DmsParamsSection({
  labels,
  values,
  fetchedTs,
}: {
  labels: ParamLabel[];
  values: Record<string, { value: unknown; unit: string | null }>;
  fetchedTs: number | null;
}) {
  // Group visible fields by category, preserving the incoming order (server has already applied saved sort_order).
  const grouped: Record<string, ParamLabel[]> = {};
  for (const f of labels) {
    if (f.hidden) continue;
    (grouped[f.category] ||= []).push(f);
  }

  const fetchedStr = fetchedTs
    ? new Date(fetchedTs * 1000).toLocaleString(undefined, { dateStyle: "short", timeStyle: "short" })
    : "never";

  return (
    <Section title={`DMS parameters (${labels.filter(l => !l.hidden).length} fields · pulled ${fetchedStr})`}>
      <div className="space-y-5">
        {Object.keys(grouped).map((cat) => (
          <div key={cat}>
            <div className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              {CATEGORY_LABEL[cat] ?? cat}
            </div>
            <div className="grid grid-cols-4 gap-x-4 gap-y-3 max-lg:grid-cols-3 max-sm:grid-cols-2">
              {grouped[cat].map((f) => {
                const entry = values[f.field];
                let display: string = "—";
                if (entry && entry.value != null && entry.value !== "") {
                  const raw = String(entry.value);
                  display = f.enumMap?.[raw] ?? raw;
                }
                const unit = f.unit ?? entry?.unit ?? "";
                return (
                  <div key={f.field} title={f.description ?? ""}>
                    <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{f.label}</div>
                    <div className="truncate text-[13px]">
                      {display}
                      {unit && display !== "—" ? <span className="ml-1 text-muted-foreground">{unit}</span> : null}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
}
