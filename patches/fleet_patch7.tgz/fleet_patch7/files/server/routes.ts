import type { Express } from "express";
import type { Server } from "http";
import {
  getSummary, listRigs, getFilterOptions, getRig, getPeerStats,
  listReports, runReport, runSql, type RigFilters,
} from "./storage";
import { getWalkDays, getWalkLog, getWalkLogCsv } from "./walklog";
import {
  getFieldCatalog, runSearch, listCustomReports, saveCustomReport, deleteCustomReport,
  type Condition,
} from "./search";
import { startScan, scanStatus } from "./walkscan";
import { runDailyReport, getDailyReport, reportStatus } from "./dailyreport";
import { sessionsHealth, backfillSessions, refreshActivityFlags,
  liveState, configureLive, sweepAll, liveBoard, workDays, collectWorkNow, RULE_FIELDS,
  listRules, createRule, toggleRule, deleteRule, listEvents, ackEvent, ackAllEvents,
  seedDefaultRules, liveDb, recentFaults, dmsLiveSnapshot, verifyMapPullAuth, matchReview,
} from "./live";
import {
  fieldsWithLabels, upsertLabel, resetLabel, upsertEnumLabel, deleteEnumLabel, saveFieldOrder,
  getParams, lastFetchTs, onRigWake, paramHistory, PARAM_CATALOG, isNumericParam, paramsToImperial,
} from "./params";
import {
  fetchVpForSn, getCurrentProfile, listProfileHistory, listProfileHistoryDedup, getProfileById, lastVpFetchTs,
} from "./vpLibrary";
import { seedSuggestions, listSuggestions, approveSuggestion, dismissSuggestion, approveAllSuggestions } from "./suggestions";
import { registerSetupRoutes } from "./setups";
import { registerHubspotLinkRoutes, hubspotLinkConfigured } from "./hubspot-link";
import { registerElevation } from "./elevation";
import { registerTerrain } from "./terrain";

function toCsv(rows: Record<string, unknown>[]): string {
  if (!rows.length) return "";
  const cols = Object.keys(rows[0]);
  const esc = (v: unknown) => {
    if (v === null || v === undefined) return "";
    const s = String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [cols.join(","), ...rows.map((r) => cols.map((c) => esc(r[c])).join(","))].join("\n");
}

export function registerRoutes(httpServer: Server, app: Express) {
  registerSetupRoutes(app);
  registerElevation(app);
  registerTerrain(app);

  app.get("/api/summary", (_req, res) => {
    res.json(getSummary());
  });

  app.get("/api/filters", (_req, res) => {
    res.json(getFilterOptions());
  });

  // ---------- Custom search ----------
  app.get("/api/search/fields", (_req, res) => {
    res.json(getFieldCatalog());
  });

  app.post("/api/search", (req, res) => {
    try {
      const { conditions, quick, limit, format, display } = req.body as {
        conditions?: Condition[]; quick?: string; limit?: number; format?: string; display?: string[];
      };
      const result = runSearch(conditions ?? [], quick, limit ?? 2000, display);
      if (format === "csv") {
        res.setHeader("Content-Type", "text/csv");
        res.setHeader("Content-Disposition", `attachment; filename="search.csv"`);
        return res.send(toCsv(result.rows as Record<string, unknown>[]));
      }
      res.json(result);
    } catch (e) {
      res.status(400).json({ error: String((e as Error).message) });
    }
  });

  // ---------- Saved custom reports ----------
  app.get("/api/custom-reports", (_req, res) => {
    res.json(listCustomReports());
  });

  app.post("/api/custom-reports", (req, res) => {
    const { name, description, conditions, quick } = req.body as {
      name?: string; description?: string; conditions?: Condition[]; quick?: string;
    };
    if (!name || !name.trim()) return res.status(400).json({ error: "name required" });
    if (!conditions?.length && !(quick && quick.trim()))
      return res.status(400).json({ error: "at least one filter or quick search required" });
    const id = saveCustomReport(name.trim(), description ?? "", conditions ?? [], quick, (req.body as { display?: string[] }).display);
    res.json({ id });
  });

  app.delete("/api/custom-reports/:id", (req, res) => {
    deleteCustomReport(Number(req.params.id));
    res.json({ ok: true });
  });

  app.get("/api/rigs", (req, res) => {
    const q = req.query;
    const filters: RigFilters = {
      q: (q.q as string) || undefined,
      machine: (q.machine as string) || undefined,
      brand: (q.brand as string) || undefined,
      state: (q.state as string) || undefined,
      firmware: (q.firmware as string) || undefined,
      activity: (q.activity as RigFilters["activity"]) || undefined,
      app: (q.app as string) || undefined,
      steeringWheel: (q.steeringWheel as string) || undefined,
      sort: (q.sort as string) || undefined,
      dir: (q.dir as "asc" | "desc") || undefined,
      limit: q.limit ? Number(q.limit) : undefined,
      offset: q.offset ? Number(q.offset) : undefined,
    };
    if (q.format === "csv") {
      const { rows } = listRigs({ ...filters, limit: 1000, offset: 0 });
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="rigs.csv"`);
      return res.send(toCsv(rows as Record<string, unknown>[]));
    }
    res.json(listRigs(filters));
  });

  app.get("/api/rig/:sn", (req, res) => {
    const detail = getRig(req.params.sn);
    if (!detail) return res.status(404).json({ error: "not found" });
    // HubSpot customer enrichment (serial_contacts lives in livedata.db)
    try {
      const c = liveDb
        .prepare(`SELECT name, email, phone, hubspot_contact_link, hubspot_deal_link, source, confidence, evidence, updated_ts FROM serial_contacts WHERE sn = ?`)
        .get(req.params.sn) as { name?: string; email?: string; phone?: string; hubspot_contact_link?: string; hubspot_deal_link?: string; source?: string; confidence?: string; evidence?: string; updated_ts?: number } | undefined;
      if (c && (c.name || c.hubspot_contact_link || c.hubspot_deal_link)) {
        (detail as Record<string, unknown>).hubspot = {
          name: c.name ?? null,
          email: c.email ?? null,
          phone: c.phone ?? null,
          link: c.hubspot_contact_link || c.hubspot_deal_link || null,
          source: c.source ?? null,
          confidence: c.confidence ?? "high",
          evidence: c.evidence ?? null,
          updated_ts: c.updated_ts ?? null,
        };
      }
      (detail as Record<string, unknown>).hubspotLinkConfigured = hubspotLinkConfigured();
    } catch { /* serial_contacts not present yet */ }
    res.json(detail);
  });

  app.get("/api/rig/:sn/walkdays", (req, res) => {
    res.json({ days: getWalkDays(req.params.sn) });
  });

  app.get("/api/rig/:sn/walklog/:day", async (req, res) => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(req.params.day)) return res.status(400).json({ error: "bad day" });
    req.setTimeout(300_000);
    try {
      const from = req.query.from ? Number(req.query.from) : undefined;
      const to = req.query.to ? Number(req.query.to) : undefined;
      const result = await getWalkLog(req.params.sn, req.params.day, req.query.force === "1", from, to);
      res.json(result);
    } catch (e) {
      res.status(502).json({ error: (e as Error).message });
    }
  });

  app.get("/api/rig/:sn/walklog/:day/csv", (req, res) => {
    const csv = getWalkLogCsv(req.params.sn, req.params.day);
    if (!csv) return res.status(404).json({ error: "no cached data for that day" });
    res.setHeader("Content-Type", "text/csv");
    res.setHeader("Content-Disposition", `attachment; filename="walklog_${req.params.sn}_${req.params.day}.csv"`);
    res.send(csv);
  });

  app.get("/api/rig/:sn/peers", (req, res) => {
    const stats = getPeerStats(req.params.sn);
    if (!stats) return res.status(404).json({ error: "not found" });
    res.json(stats);
  });

  app.get("/api/reports", (_req, res) => {
    res.json(listReports());
  });

  app.get("/api/reports/:id", (req, res) => {
    const result = runReport(req.params.id);
    if (!result) return res.status(404).json({ error: "unknown report" });
    if (req.query.format === "csv") {
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="${req.params.id}.csv"`);
      return res.send(toCsv(result.rows as Record<string, unknown>[]));
    }
    res.json(result);
  });

  app.post("/api/sql", (req, res) => {
    try {
      const { sql } = req.body as { sql: string };
      if (!sql) return res.status(400).json({ error: "sql required" });
      const rows = runSql(sql);
      res.json({ rows });
    } catch (e) {
      res.status(400).json({ error: (e as Error).message });
    }
  });

  app.post("/api/walkscan/start", (req, res) => {
    const b = (req.body ?? {}) as Record<string, unknown>;
    const numOrNull = (v: unknown) => (v === null || v === undefined || v === "" || v === "any" ? null : Number(v));
    const criteria = {
      windowDays: Math.min(60, Math.max(1, Number(b.windowDays ?? 14))),
      daysPerRig: Math.min(3, Math.max(1, Number(b.daysPerRig ?? 1))),
      minOffsetIn: Math.max(0, Number(b.minOffsetIn ?? 1.5)),
      minSpeedMph: Math.max(0, Number(b.minSpeedMph ?? 0.1)),
      modes: b.mode === null || b.mode === undefined || b.mode === "" || b.mode === "any"
        ? null
        : String(b.mode).split(",").map((s) => Number(s.trim())).filter((n) => Number.isFinite(n)),
      gpsStatus: numOrNull(b.gpsStatus),
      episodeGapS: Math.max(5, Number(b.episodeGapS ?? 30)),
    };
    const r = startScan(criteria);
    if (!r.ok) return res.status(409).json(r);
    res.json({ ok: true, criteria });
  });

  app.get("/api/daily-report/status", (_req, res) => res.json(reportStatus()));
  app.get("/api/daily-report/:day", (req, res) => res.json(getDailyReport(req.params.day)));
  app.post("/api/daily-report/run/:day", async (req, res) => {
    try { res.json(await runDailyReport(req.params.day)); }
    catch (e) { res.status(409).json({ error: (e as Error).message }); }
  });

  app.get("/api/walkscan/status", (_req, res) => {
    res.json(scanStatus());
  });

  app.post("/api/sql/csv", (req, res) => {
    try {
      const { sql } = req.body as { sql: string };
      if (!sql) return res.status(400).json({ error: "sql required" });
      const rows = runSql(sql) as Record<string, unknown>[];
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="query.csv"`);
      res.send(toCsv(rows));
    } catch (e) {
      res.status(400).json({ error: (e as Error).message });
    }
  });

  // ---------------- Live Monitor ----------------
  app.get("/api/live/state", (_req, res) => res.json(liveState()));

  // Pull endpoint: same payload shape the fleet pushes to the map every cycle.
  // The map app hits this on boot to hydrate its DMS-live layer immediately
  // instead of waiting up to ~3 min for the next scheduled push. Bearer
  // auth uses the same token as the outbound push — only the map has it.
  app.get("/api/dms-live/snapshot", (req, res) => {
    if (!verifyMapPullAuth({
      authorization: req.headers.authorization,
      xDmsToken: req.headers["x-dms-token"],
      queryToken: (req.query as any)?.token,
    })) {
      return res.status(401).json({ ok: false, error: "unauthorized" });
    }
    // Return { ok: true, snapshot: null } when the poller hasn't run yet
    // so callers can distinguish "fleet up, no data yet" from a network error.
    const state = liveState() as any;
    if (!state.lastCycle) return res.json({ ok: true, snapshot: null });
    return res.json({ ok: true, snapshot: dmsLiveSnapshot() });
  });

  app.post("/api/live/config", (req, res) => {
    const { running, intervalS, watchScope, mapPushEnabled, mapPushUrl, mapPushToken, panAuth } = req.body as {
      running?: boolean; intervalS?: number; watchScope?: string;
      mapPushEnabled?: boolean; mapPushUrl?: string; mapPushToken?: string; panAuth?: string;
    };
    configureLive({ running, intervalS, watchScope, mapPushEnabled, mapPushUrl, mapPushToken, panAuth });
    res.json(liveState());
  });

  // Sessions feed health + manual backfill trigger (see live.ts backfillSessions).
  app.get("/api/sessions/health", (_req, res) => res.json(sessionsHealth()));
  app.post("/api/sessions/backfill", (req, res) => {
    const from = typeof req.query.from === "string" && /^\d{4}-\d{2}-\d{2}$/.test(req.query.from) ? req.query.from : undefined;
    void backfillSessions(from);
    res.json(sessionsHealth());
  });
  app.post("/api/sessions/refresh-flags", (_req, res) => { refreshActivityFlags(); res.json(sessionsHealth()); });

  app.post("/api/live/sweep", (_req, res) => {
    const started = sweepAll();
    res.json({ started, ...liveState() });
  });

  app.get("/api/live/board", (_req, res) => res.json(liveBoard()));
  // Multi-key customer matcher output: unmatched rigs, needs-review, shared logins, HubSpot write-back log.
  app.get("/api/live/match-review", (_req, res) => res.json(matchReview()));
  // Manual serial -> HubSpot contact linking (search, link, unlink, audit log).
  registerHubspotLinkRoutes(app);

  // Daily work stats (acreage rollups) from the official FJD API
  app.get("/api/work/days", (req, res) => res.json(workDays(parseInt(String(req.query.days ?? "30"), 10) || 30)));
  app.post("/api/work/collect", (_req, res) => res.json(collectWorkNow()));

  // Daily work stats (acreage rollups) from the official FJD API
  app.get("/api/work/days", (req, res) => res.json(workDays(parseInt(String(req.query.days ?? "30"), 10) || 30)));
  app.post("/api/work/collect", (_req, res) => res.json(collectWorkNow()));

  app.get("/api/live/fields", (_req, res) => {
    const live = Object.entries(RULE_FIELDS).map(([key, f]) => ({
      key, label: f.label, unit: f.unit ?? null, category: "live", description: null as string | null,
    }));
    const params = fieldsWithLabels()
      .filter((p) => !p.hidden && p.numeric)
      .map((p) => ({
        key: `param.${p.field}`, label: p.label, unit: p.unit,
        category: `param · ${p.category}`, description: p.description,
      }));
    res.json([...live, ...params]);
  });

  // ---------------- Admin: parameter labels + enum overrides ----------------
  function requireAdmin(req: any, res: any, next: any) {
    // LAN sessions have no user attached and are treated as admin (see auth.ts).
    const u = req.user;
    if (!u || u.role === "admin") return next();
    return res.status(403).json({ error: "admin only" });
  }

  app.get("/api/params/labels", (_req, res) => res.json(fieldsWithLabels()));

  // Bulk save field ordering. Body: { fields: ["lateralSensitivity", "headingSensitivity", ...] }
  app.put("/api/params/order", requireAdmin, (req, res) => {
    try {
      const body = req.body ?? {};
      if (!Array.isArray(body.fields)) return res.status(400).json({ error: "body.fields must be an array of field names" });
      saveFieldOrder(body.fields as string[]);
      res.json({ ok: true, count: body.fields.length });
    } catch (e: any) {
      res.status(400).json({ error: String(e?.message ?? e) });
    }
  });

  app.patch("/api/params/labels/:field", requireAdmin, (req, res) => {
    try {
      upsertLabel(req.params.field, req.body ?? {});
      res.json({ ok: true });
    } catch (e) {
      res.status(400).json({ error: (e as Error).message });
    }
  });

  app.delete("/api/params/labels/:field", requireAdmin, (req, res) => {
    resetLabel(req.params.field);
    res.json({ ok: true });
  });

  app.post("/api/params/labels/:field/enum", requireAdmin, (req, res) => {
    const { raw_value, display } = req.body as { raw_value?: string; display?: string };
    if (raw_value == null || !display) return res.status(400).json({ error: "raw_value and display required" });
    upsertEnumLabel(req.params.field, String(raw_value), display);
    res.json({ ok: true });
  });

  app.delete("/api/params/labels/:field/enum/:raw", requireAdmin, (req, res) => {
    deleteEnumLabel(req.params.field, req.params.raw);
    res.json({ ok: true });
  });

  // Per-rig params view (values + last fetch time + history)
  app.get("/api/rig/:sn/params", (req, res) => {
    const raw = getParams(req.params.sn);
    res.json({
      sn: req.params.sn,
      fetched_ts: lastFetchTs(req.params.sn),
      data: raw ? paramsToImperial(raw) : null,
      raw,
      history: paramHistory(req.params.sn, 100),
    });
  });

  // Manual re-poll (admin only, mostly for debugging)
  app.post("/api/rig/:sn/params/refresh", requireAdmin, async (req, res) => {
    const ok = await onRigWake(req.params.sn);
    res.json({ ok, fetched_ts: lastFetchTs(req.params.sn) });
  });

  // catalog for reference / debugging
  app.get("/api/params/catalog", (_req, res) => res.json(PARAM_CATALOG));

  // ---------- Suggested renames (staged, admin approves) ----------
  seedSuggestions();

  app.get("/api/params/suggestions", (_req, res) => res.json(listSuggestions()));

  app.post("/api/params/suggestions/:field/approve", requireAdmin, (req, res) => {
    try {
      approveSuggestion(req.params.field);
      res.json({ ok: true });
    } catch (e) {
      res.status(400).json({ error: (e as Error).message });
    }
  });

  app.post("/api/params/suggestions/:field/dismiss", requireAdmin, (req, res) => {
    dismissSuggestion(req.params.field);
    res.json({ ok: true });
  });

  app.post("/api/params/suggestions/approve-all", requireAdmin, (_req, res) => {
    res.json({ ok: true, approved: approveAllSuggestions() });
  });

  // ---------- Vehicle Profile Library (FJD DMS Vehicle Info Repo) ----------
  // Current active tractor profile assigned to this SN
  app.get("/api/rig/:sn/vp/current", (req, res) => {
    res.json({
      sn: req.params.sn,
      fetched_ts: lastVpFetchTs(req.params.sn),
      current: getCurrentProfile(req.params.sn),
    });
  });

  // All saved profiles for this SN. Default: dedup'd to only rows where a
  // tracked field changed vs the prior save (with `changes: [{field,from,to}]`).
  // Pass ?full=1 for the raw list of every saved profile.
  app.get("/api/rig/:sn/vp/history", (req, res) => {
    const full = req.query.full === "1" || req.query.full === "true";
    res.json({
      sn: req.params.sn,
      fetched_ts: lastVpFetchTs(req.params.sn),
      dedup: !full,
      profiles: full ? listProfileHistory(req.params.sn) : listProfileHistoryDedup(req.params.sn),
    });
  });

  // One historical profile in full
  app.get("/api/vp/:id", (req, res) => {
    const p = getProfileById(Number(req.params.id));
    if (!p) return res.status(404).json({ error: "not found" });
    res.json(p);
  });

  // Force-refresh the VP library for this SN (admin only)
  app.post("/api/rig/:sn/vp/refresh", requireAdmin, async (req, res) => {
    const r = await fetchVpForSn(req.params.sn);
    res.json(r);
  });

  app.get("/api/live/rules", (_req, res) => res.json(listRules()));

  app.post("/api/live/rules", (req, res) => {
    const b = req.body as {
      name?: string;
      conditions?: { field?: string; op?: string; value?: number; value2?: number | null }[];
      sustain_min?: number | null;
      // legacy single-condition shape (kept so old clients/scripts still work)
      field?: string; op?: string; value?: number; value2?: number | null;
      only_moving?: boolean;
    };
    const raw = Array.isArray(b.conditions) && b.conditions.length
      ? b.conditions
      : b.field !== undefined ? [{ field: b.field, op: b.op, value: b.value, value2: b.value2 }] : [];
    if (!b.name || !raw.length)
      return res.status(400).json({ error: "name and at least one condition required" });
    const conds = [];
    for (const c of raw) {
      const isParam = typeof c.field === "string" && c.field.startsWith("param.");
      const paramOk = isParam && isNumericParam((c.field as string).slice("param.".length));
      if (!c.field || !c.op || c.value === undefined || (!RULE_FIELDS[c.field] && !paramOk))
        return res.status(400).json({ error: `each condition needs a valid field, op, value (got: ${c.field ?? "?"})` });
      conds.push({ field: c.field, op: c.op, value: Number(c.value), value2: c.value2 != null ? Number(c.value2) : null });
    }
    const sustain = b.sustain_min != null && Number(b.sustain_min) > 0 ? Number(b.sustain_min) : null;
    res.json(createRule({ name: b.name, conditions: conds, sustain_min: sustain, only_moving: b.only_moving }));
  });

  app.patch("/api/live/rules/:id", (req, res) => {
    toggleRule(Number(req.params.id), Boolean((req.body as { enabled?: boolean }).enabled));
    res.json({ ok: true });
  });

  app.delete("/api/live/rules/:id", (req, res) => {
    deleteRule(Number(req.params.id));
    res.json({ ok: true });
  });

  app.post("/api/live/rules/seed-defaults", (_req, res) => res.json(seedDefaultRules()));

  // LIVE view: only currently-open alerts (default). Pass ?scope=all for the
  // full history table, or ?scope=daily (optional ?since=&until= epoch ms) for
  // the day's log used by reports / pattern analysis.
  app.get("/api/live/alerts", (req, res) => {
    const scope = req.query.scope === "all" ? "all" : req.query.scope === "daily" ? "daily" : "open";
    const sinceTs = req.query.since != null ? Number(req.query.since) : undefined;
    const untilTs = req.query.until != null ? Number(req.query.until) : undefined;
    const limit = Math.max(1, Math.min(5000, Number(req.query.limit) || (scope === "open" ? 500 : 2000)));
    res.json(listEvents({ scope, sinceTs, untilTs, limit }));
  });
  // Convenience alias for the daily alert log (today unless since/until given).
  app.get("/api/live/alerts/daily", (req, res) => {
    const sinceTs = req.query.since != null ? Number(req.query.since) : undefined;
    const untilTs = req.query.until != null ? Number(req.query.until) : undefined;
    const limit = Math.max(1, Math.min(5000, Number(req.query.limit) || 2000));
    res.json(listEvents({ scope: "daily", sinceTs, untilTs, limit }));
  });
  app.get("/api/live/faults", (req, res) => {
    const days = Math.max(1, Math.min(60, Number(req.query.days) || 14));
    const limit = Math.max(1, Math.min(2000, Number(req.query.limit) || 500));
    res.json(recentFaults(days, limit));
  });
  app.post("/api/live/alerts/ack-all", (_req, res) => { ackAllEvents(); res.json({ ok: true }); });
  app.post("/api/live/alerts/:id/ack", (req, res) => { ackEvent(Number(req.params.id)); res.json({ ok: true }); });
}
