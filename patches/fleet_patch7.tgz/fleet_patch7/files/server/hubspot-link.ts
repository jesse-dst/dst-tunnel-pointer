// Manual serial -> HubSpot contact linking.
//
// The multi-key matcher (scripts/match_customers.mjs) fills livedata.db
// serial_contacts automatically. For the ~130 running units it cannot place
// (personal login that exists nowhere in HubSpot, brand-new customer, used unit
// that changed hands) a person has to say "this serial belongs to that
// contact". This module gives the UI a contact search + a one-click link that:
//   1. upserts serial_contacts with source 'manual:<user>' (the matcher never
//      overwrites manual rows),
//   2. optionally writes the serial (system_serial_number), the DMS login
//      (fjd_login_info) and the serial deal association to the HubSpot contact so
//      HubSpot stays the source of truth and the Live Map picks it up on its
//      next HubSpot refresh,
//   3. pushes a fresh DMS-live snapshot to the map right away so the pin shows
//      the customer within seconds instead of at the next poll cycle.
//
// Token: ~/.dst-map/hubspot_token (same file the matcher and map sync use) or
// HUBSPOT_TOKEN env. Never logged.
import type { Express } from "express";
import fs from "fs";
import os from "os";
import path from "path";
import { db } from "./storage";
import { liveDb, pushToMapNow } from "./live";

const PORTAL = "23533734";
const SN_RE = /FJ[A-Z0-9]{13,17}/gi;
const INTERNAL_LOGIN = /@(deepsandtech\.com|fjdynamics\.com|pargps\.com)$/i;
const PROPS = ["firstname", "lastname", "email", "hs_additional_emails", "phone", "mobilephone", "city", "state",
  "system_serial_number", "all_system_serials", "fjd_login_info", "tractor_model", "createdate"];

function token(): string {
  const env = (process.env.HUBSPOT_TOKEN || "").trim();
  if (env) return env;
  try { return fs.readFileSync(path.join(os.homedir(), ".dst-map", "hubspot_token"), "utf8").trim(); } catch { return ""; }
}
export function hubspotLinkConfigured(): boolean { return token().length > 0; }

async function hs(method: string, p: string, body?: unknown): Promise<any> {
  const t = token();
  if (!t) throw new Error("HubSpot token not configured on this machine (~/.dst-map/hubspot_token)");
  for (let attempt = 0; attempt < 4; attempt++) {
    const res = await fetch("https://api.hubapi.com" + p, {
      method,
      headers: { Authorization: `Bearer ${t}`, "Content-Type": "application/json" },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    if (res.ok) return res.status === 204 ? {} : res.json();
    if ([429, 502, 503].includes(res.status) && attempt < 3) { await new Promise((r) => setTimeout(r, 2 ** attempt * 800)); continue; }
    throw new Error(`HubSpot ${res.status} ${method} ${p}: ${(await res.text()).slice(0, 240)}`);
  }
}

const clean = (v: unknown) => String(v ?? "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").trim();

export type ContactHit = {
  id: string; name: string; email: string | null; phone: string | null; location: string | null;
  serials: string[]; logins: string[]; tractor: string | null; created: string | null; link: string;
};
function shape(o: any): ContactHit {
  const p = o?.properties ?? {};
  const name = [clean(p.firstname), clean(p.lastname)].filter(Boolean).join(" ") || clean(p.email) || `Contact ${o.id}`;
  const serialsBlob = [p.all_system_serials, p.system_serial_number].filter(Boolean).join(" ; ").toUpperCase();
  return {
    id: String(o.id), name,
    email: clean(p.email) || null,
    phone: clean(p.phone) || clean(p.mobilephone) || null,
    location: [clean(p.city), clean(p.state)].filter(Boolean).join(", ") || null,
    serials: [...new Set(serialsBlob.match(SN_RE) || [])],
    logins: clean(p.fjd_login_info).toLowerCase().split(/[\s;,|/]+/).filter(Boolean),
    tractor: clean(p.tractor_model) || null,
    created: p.createdate ? String(p.createdate).slice(0, 10) : null,
    link: `https://app.hubspot.com/contacts/${PORTAL}/record/0-1/${o.id}`,
  };
}

/** Free-text contact search. Accepts a name, email, phone, HubSpot record URL or numeric contact id. */
export async function searchContacts(qRaw: string): Promise<ContactHit[]> {
  const q = qRaw.trim();
  if (!q) return [];
  const idMatch = q.match(/record\/0-1\/(\d+)/) || q.match(/^(\d{6,})$/);
  if (idMatch) {
    try { return [shape(await hs("GET", `/crm/v3/objects/contacts/${idMatch[1]}?properties=${PROPS.join(",")}`))]; } catch { return []; }
  }
  const body: any = { query: q, limit: 10, properties: PROPS, sorts: [{ propertyName: "createdate", direction: "DESCENDING" }] };
  const r = await hs("POST", "/crm/v3/objects/contacts/search", body);
  let hits: ContactHit[] = (r?.results ?? []).map(shape);
  // HubSpot's free-text search skips custom properties, so also try the serial /
  // FJD-login fields directly when the query looks like one of those.
  if (/^FJ[A-Z0-9]{6,}/i.test(q) || q.includes("@")) {
    const prop = q.includes("@") ? "fjd_login_info" : "system_serial_number";
    const r2 = await hs("POST", "/crm/v3/objects/contacts/search", {
      filterGroups: [{ filters: [{ propertyName: prop, operator: "CONTAINS_TOKEN", value: q.includes("@") ? q.toLowerCase() : q.toUpperCase() }] }],
      limit: 10, properties: PROPS,
    }).catch(() => null);
    for (const o of r2?.results ?? []) if (!hits.some((h) => h.id === String(o.id))) hits.push(shape(o));
  }
  return hits.slice(0, 15);
}

export type LinkResult = { ok: true; sn: string; contact: ContactHit; source: string; hubspot: string[]; mapPushed: boolean };

/** Link one serial to one HubSpot contact. `by` = signed-in user name for the audit trail. */
export async function linkSerial(snRaw: string, contactId: string, by: string, writeHubspot: boolean): Promise<LinkResult> {
  const sn = snRaw.trim().toUpperCase();
  if (!/^FJ[A-Z0-9]{13,17}$/.test(sn)) throw new Error(`"${snRaw}" is not an FJD serial`);
  if (!/^\d+$/.test(contactId)) throw new Error("contactId must be numeric");
  const contact = shape(await hs("GET", `/crm/v3/objects/contacts/${contactId}?properties=${PROPS.join(",")}`));
  const rig = db.prepare("SELECT sn, customer_email FROM rigs WHERE sn = ?").get(sn) as { sn: string; customer_email: string | null } | undefined;

  const hubspot: string[] = [];
  let dealLink: string | null = null;
  if (writeHubspot) {
    // 1) serial onto the contact (append, dedupe, keep existing order)
    if (!contact.serials.includes(sn)) {
      const raw = await hs("GET", `/crm/v3/objects/contacts/${contactId}?properties=system_serial_number`);
      const cur = clean(raw?.properties?.system_serial_number);
      const list = [...new Set([...(cur.toUpperCase().match(SN_RE) || []), sn])];
      await hs("PATCH", `/crm/v3/objects/contacts/${contactId}`, { properties: { system_serial_number: list.join("; ") } });
      contact.serials = list; hubspot.push(`serial ${sn} added to System Serial Number`);
    }
    // 2) the DMS login this unit actually uses -> FJD Login Info (skip DST/FJD internal logins)
    const login = (rig?.customer_email || "").trim().toLowerCase();
    if (login.includes("@") && !INTERNAL_LOGIN.test(login) && !contact.logins.includes(login)) {
      const raw = await hs("GET", `/crm/v3/objects/contacts/${contactId}?properties=fjd_login_info`);
      const cur = clean(raw?.properties?.fjd_login_info);
      await hs("PATCH", `/crm/v3/objects/contacts/${contactId}`, { properties: { fjd_login_info: cur ? `${cur}; ${login}` : login } });
      contact.logins.push(login); hubspot.push(`FJD login ${login} added`);
    }
    // 3) the serial's deal (if one exists) -> associated to this contact
    try {
      const deals = await hs("POST", "/crm/v3/objects/deals/search", {
        filterGroups: [{ filters: [{ propertyName: "system_serial_number", operator: "CONTAINS_TOKEN", value: sn }] }],
        properties: ["dealname", "system_serial_number"], limit: 5,
      });
      const deal = (deals?.results ?? []).find((d: any) => (clean(d.properties?.system_serial_number).toUpperCase().match(SN_RE) || []).includes(sn));
      if (deal) {
        dealLink = `https://app.hubspot.com/contacts/${PORTAL}/record/0-3/${deal.id}`;
        const assoc = await hs("GET", `/crm/v4/objects/deals/${deal.id}/associations/contacts`).catch(() => null);
        const already = (assoc?.results ?? []).some((a: any) => String(a.toObjectId) === contactId);
        if (!already) {
          await hs("PUT", `/crm/v4/objects/deals/${deal.id}/associations/default/contacts/${contactId}`);
          hubspot.push(`deal "${clean(deal.properties?.dealname) || deal.id}" associated`);
        }
      }
    } catch (e: any) { hubspot.push(`deal association skipped: ${e.message}`); }
  }

  const source = `manual:${(by || "user").replace(/[^A-Za-z0-9._ -]/g, "").slice(0, 40) || "user"}`;
  const evidence = JSON.stringify({ by: by || "user", at: new Date().toISOString(), hubspot_writes: hubspot, reasons: ["manual link"] });
  liveDb.prepare(`INSERT INTO serial_contacts (sn,name,email,phone,hubspot_contact_link,hubspot_deal_link,source,confidence,evidence,updated_ts)
    VALUES (@sn,@name,@email,@phone,@clink,@dlink,@source,'manual',@evidence,@ts)
    ON CONFLICT(sn) DO UPDATE SET name=excluded.name, email=excluded.email, phone=excluded.phone,
      hubspot_contact_link=excluded.hubspot_contact_link,
      hubspot_deal_link=COALESCE(excluded.hubspot_deal_link, serial_contacts.hubspot_deal_link),
      source=excluded.source, confidence='manual', evidence=excluded.evidence, updated_ts=excluded.updated_ts`)
    .run({ sn, name: contact.name, email: contact.email, phone: contact.phone, clink: contact.link, dlink: dealLink, source, evidence, ts: Date.now() });
  liveDb.prepare(`INSERT INTO manual_link_log (sn, contact_id, contact_name, by_user, action, detail, ts) VALUES (?,?,?,?,?,?,?)`)
    .run(sn, contactId, contact.name, by || "user", "link", JSON.stringify(hubspot), Date.now());

  let mapPushed = false;
  try { await pushToMapNow(); mapPushed = true; } catch { /* next cycle will carry it */ }
  return { ok: true, sn, contact, source, hubspot, mapPushed };
}

/** Remove a manual (or any) link for a serial. Local only — HubSpot is not changed. */
export async function unlinkSerial(snRaw: string, by: string): Promise<{ ok: true; sn: string; removed: number; mapPushed: boolean }> {
  const sn = snRaw.trim().toUpperCase();
  const prev = liveDb.prepare("SELECT name FROM serial_contacts WHERE sn = ?").get(sn) as { name: string | null } | undefined;
  const removed = liveDb.prepare("DELETE FROM serial_contacts WHERE sn = ?").run(sn).changes;
  liveDb.prepare(`INSERT INTO manual_link_log (sn, contact_id, contact_name, by_user, action, detail, ts) VALUES (?,?,?,?,?,?,?)`)
    .run(sn, null, prev?.name ?? null, by || "user", "unlink", null, Date.now());
  let mapPushed = false;
  try { await pushToMapNow(); mapPushed = true; } catch { /* fine */ }
  return { ok: true, sn, removed, mapPushed };
}

export function manualLinkLog(limit = 50) {
  return liveDb.prepare("SELECT sn, contact_id, contact_name, by_user, action, detail, ts FROM manual_link_log ORDER BY ts DESC LIMIT ?").all(limit);
}

export function registerHubspotLinkRoutes(app: Express) {
  liveDb.exec(`CREATE TABLE IF NOT EXISTS manual_link_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT, sn TEXT, contact_id TEXT, contact_name TEXT, by_user TEXT, action TEXT, detail TEXT, ts INTEGER
  )`);
  const who = (req: any) => String(req.user?.name || (req.user ? req.user.userId : "LAN") || "LAN");

  app.get("/api/hubspot/contacts", async (req, res) => {
    const q = String(req.query.q ?? "");
    if (q.trim().length < 2) return res.json({ configured: hubspotLinkConfigured(), results: [] });
    try { res.json({ configured: true, results: await searchContacts(q) }); }
    catch (e: any) { res.status(502).json({ error: e.message }); }
  });
  app.post("/api/rig/:sn/contact", async (req, res) => {
    const { contactId, writeHubspot } = (req.body ?? {}) as { contactId?: string | number; writeHubspot?: boolean };
    if (!contactId) return res.status(400).json({ error: "contactId required" });
    try { res.json(await linkSerial(req.params.sn, String(contactId), who(req), writeHubspot !== false)); }
    catch (e: any) { res.status(400).json({ error: e.message }); }
  });
  app.delete("/api/rig/:sn/contact", async (req, res) => {
    try { res.json(await unlinkSerial(req.params.sn, who(req))); }
    catch (e: any) { res.status(400).json({ error: e.message }); }
  });
  app.get("/api/live/manual-links", (_req, res) => res.json(manualLinkLog()));
}
