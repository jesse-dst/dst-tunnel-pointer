import Database from "better-sqlite3";
import path from "path";
import fs from "fs";
import { db } from "./storage";
import { fjdRealtimeStatus, fjdNetwork, fjdOperationStats, fjdConfigured, type FjdRealtime } from "./fjdApi";

// ---------------------------------------------------------------------------
// Live Monitor — polls the official FJD Data Service API (signed, keyed,
// no cookies), stores snapshots, evaluates alert rules, joins DST customer
// map. The DMS cookie path remains only for the dealer-dashboard overview,
// fault feed, and wake-edge parameter fetch (not exposed by the official API).
// ---------------------------------------------------------------------------

const PAN_BASE = "https://pan-agriculture-us.fjdac.com";
const PAN_AUTH =
  "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIxNTgwODMxNjQ0MDgzODcxNzQ2IiwicGxhdGZvcm1JZHMiOlsxNTc5ODAzMTc4NDY3MTg0NjQyLDE2MzA0NzcxOTMzODAzNzI0ODEsMTY0NjA0Njc0MzQ1NDgxMDExNCwxNjU0MzY4Mjc0MjMyNzU0MTc4LDE3NTIyMTU1MTk0MDA5MjMxMzddLCJpYXQiOjE3ODM3OTM0MjV9.kEJYx-qmY_BlF55vFSuvIVGEOACo8fUgxqq7jAHgBVM";
// The dealer-portal token can be replaced without a rebuild: PAN_AUTH env var
// wins, then the `panAuth` row in live_settings (POST /api/live/config
// {panAuth}), then the baked-in default above. The portal started rejecting the
// baked-in token for dealerDashboard/* on 2026-08-31 ("not logged in"), which
// is why faults + the dealer online count went blank; walking logs kept working.
function panHeaders(): Record<string, string> {
  let tok = PAN_AUTH;
  try {
    tok = process.env.PAN_AUTH || (liveDb.prepare("SELECT value FROM live_settings WHERE key='panAuth'").get() as { value: string } | undefined)?.value || PAN_AUTH;
  } catch { /* settings table not ready yet */ }
  return { Authorization: tok, "x-platform-header": "1654368274232754178", accept: "application/json" };
}

export const liveDb = new Database(path.resolve("./livedata.db"));

/** Output of scripts/match_customers.mjs (nightly multi-key customer matcher). */
export function matchReview(): Record<string, unknown> {
  try {
    const raw = fs.readFileSync(path.resolve("./match-review-latest.json"), "utf8");
    const review = JSON.parse(raw);
    // Serials a person has linked by hand since the matcher last ran drop out of
    // the to-do lists immediately (the file itself is only rewritten by the matcher).
    try {
      const manual = new Set((liveDb.prepare("SELECT sn FROM serial_contacts WHERE source LIKE 'manual%'").all() as { sn: string }[]).map((r) => r.sn));
      if (manual.size) {
        for (const k of ["unmatched", "needs_review", "internal"]) {
          if (Array.isArray(review[k])) review[k] = review[k].filter((r: { sn: string }) => !manual.has(r.sn));
        }
        review.manual_links = manual.size;
      }
    } catch { /* livedata not ready */ }
    return review;
  } catch {
    return { generated: null, tally: {}, unmatched: [], needs_review: [], shared_logins: [], hubspot_writes: [] };
  }
}
liveDb.pragma("journal_mode = WAL");
liveDb.exec(`
CREATE TABLE IF NOT EXISTS live_history (
  sn TEXT NOT NULL, ts INTEGER NOT NULL,
  is_online INTEGER, work_status INTEGER,
  lat REAL, lng REAL, speed_ms REAL, heading REAL,
  rtk_status INTEGER, gps_work_status INTEGER, satellites INTEGER, moved INTEGER,
  PRIMARY KEY (sn, ts)
);

CREATE TABLE IF NOT EXISTS live_latest (
  sn TEXT PRIMARY KEY, ts INTEGER,
  is_online INTEGER, work_status INTEGER,
  lat REAL, lng REAL, speed_ms REAL, heading REAL,
  rtk_status INTEGER, gps_work_status INTEGER, satellites INTEGER, moved INTEGER,
  prev_lat REAL, prev_lng REAL, prev_ts INTEGER
);
CREATE TABLE IF NOT EXISTS alert_rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, field TEXT NOT NULL, op TEXT NOT NULL,
  value REAL, value2 REAL,
  enabled INTEGER DEFAULT 1, only_moving INTEGER DEFAULT 0,
  created_ts INTEGER
);
CREATE TABLE IF NOT EXISTS alert_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  rule_id INTEGER, sn TEXT, ts INTEGER,
  message TEXT, value REAL, ack_ts INTEGER
);
CREATE INDEX IF NOT EXISTS idx_events_open ON alert_events(ack_ts, ts DESC);
CREATE TABLE IF NOT EXISTS live_settings (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  pin_title TEXT, customer_name TEXT, email TEXT, address TEXT,
  hubspot_link TEXT, deal_stages TEXT, system TEXT
);
CREATE TABLE IF NOT EXISTS customer_serials (sn TEXT PRIMARY KEY, customer_id INTEGER);
CREATE TABLE IF NOT EXISTS contacts (
  email TEXT PRIMARY KEY, name TEXT, phone TEXT, hubspot_contact_link TEXT
);
CREATE TABLE IF NOT EXISTS serial_contacts (
  sn TEXT PRIMARY KEY, name TEXT, email TEXT, phone TEXT,
  hubspot_contact_link TEXT, hubspot_deal_link TEXT, source TEXT
);
`);
// Migration: multi-key matcher adds confidence/evidence to serial_contacts.
for (const col of ["confidence TEXT", "evidence TEXT", "updated_ts INTEGER"]) {
  try { liveDb.exec(`ALTER TABLE serial_contacts ADD COLUMN ${col}`); } catch { /* exists */ }
}

// Migration: shared triage state pushed to / relayed back from the map app.
for (const col of ["reviewed", "contacted"]) {
  try { liveDb.exec(`ALTER TABLE alert_events ADD COLUMN ${col} INTEGER DEFAULT 0`); } catch (_) { /* column exists */ }
}

// Migration: alert lifecycle. An event is OPEN while resolved_ts IS NULL. It is
// auto-resolved when the rule condition stops holding, the rig's RTK returns to
// FIXED, or the rig goes offline. `last_seen_ts` tracks the most recent cycle
// the condition was still true (so one open event per rig+rule spans the whole
// episode instead of spawning a duplicate every few hours). `resolved_reason`
// is a short machine tag: 'condition cleared' | 'system offline' | 'manual'.
for (const [col, typ] of [
  ["resolved_ts", "INTEGER"], ["resolved_reason", "TEXT"], ["last_seen_ts", "INTEGER"],
] as const) {
  try { liveDb.exec(`ALTER TABLE alert_events ADD COLUMN ${col} ${typ}`); } catch (_) { /* column exists */ }
}
// Backfill last_seen_ts for pre-migration rows so duration math never sees null.
try { liveDb.exec("UPDATE alert_events SET last_seen_ts=ts WHERE last_seen_ts IS NULL"); } catch (_) { /* noop */ }
// Open-event lookups now key on resolved_ts (the true lifecycle flag), not ack_ts.
try { liveDb.exec("CREATE INDEX IF NOT EXISTS idx_events_unresolved ON alert_events(resolved_ts, sn, rule_id)"); } catch (_) { /* noop */ }


liveDb.exec(`
CREATE TABLE IF NOT EXISTS dms_faults (
  sn TEXT NOT NULL, create_ts INTEGER NOT NULL, fault_code TEXT NOT NULL,
  fault_name TEXT, fault_content TEXT, handling_advice TEXT,
  error_category INTEGER, upload_ts INTEGER,
  PRIMARY KEY (sn, create_ts, fault_code)
);
`);

// migration: connection-state columns (appConnState is the only trustworthy DMS live flag)
const latestCols = (liveDb.prepare("PRAGMA table_info(live_latest)").all() as { name: string }[]).map((c) => c.name);
if (!latestCols.includes("connected")) liveDb.exec("ALTER TABLE live_latest ADD COLUMN connected INTEGER");
if (!latestCols.includes("conn_ts")) liveDb.exec("ALTER TABLE live_latest ADD COLUMN conn_ts INTEGER");

// migration: network-health columns (official API /device/network — carrier,
// 4G-vs-WiFi, signal). Only populated for connected rigs, throttled to 15 min.
for (const [col, typ] of [
  ["net_mode", "TEXT"], ["net_operator", "TEXT"], ["net_rssi", "INTEGER"], ["net_ts", "INTEGER"],
] as const) {
  if (!latestCols.includes(col)) liveDb.exec(`ALTER TABLE live_latest ADD COLUMN ${col} ${typ}`);
}

// Daily work rollups from the official API's /device/operationStats.
// Areas are stored raw in mu (1 mu ≈ 0.1647 ac) — the UI converts to acres.
liveDb.exec(`
CREATE TABLE IF NOT EXISTS work_days (
  sn TEXT NOT NULL, day TEXT NOT NULL,
  batch_count INTEGER, total_area_mu REAL, total_time_h REAL,
  auto_area_mu REAL, manual_area_mu REAL, open_batches INTEGER,
  fetched_ts INTEGER,
  PRIMARY KEY (sn, day)
);
`);

// migration: compound alert rules — `conditions` is a JSON array of
// {field,op,value,value2} that must ALL match (AND); `sustain_min` is how many
// minutes the whole rule must stay true before it fires. Legacy single-field
// rules keep using field/op/value with conditions NULL.
const ruleCols = (liveDb.prepare("PRAGMA table_info(alert_rules)").all() as { name: string }[]).map((c) => c.name);
if (!ruleCols.includes("conditions")) liveDb.exec("ALTER TABLE alert_rules ADD COLUMN conditions TEXT");
if (!ruleCols.includes("sustain_min")) liveDb.exec("ALTER TABLE alert_rules ADD COLUMN sustain_min REAL");
// migration: online_since — when the terminal's current connect session began
// (powers the online_minutes rule field, e.g. "system on for over 3 minutes").
if (!latestCols.includes("online_since")) liveDb.exec("ALTER TABLE live_latest ADD COLUMN online_since INTEGER");

// ---------------- rigs.last_session_time freshness ----------------
// The Rigs page's "Last session" comes from rigs.last_session_time in data.db,
// which the original cookie-based DMS import stopped updating when the cookies
// died (frozen at 2026-07-21). Keep it fresh from official-API activity:
// touched whenever a rig is seen connected or logs a work day. Writable handle
// is separate from storage.ts's readonly one — that's fine for sqlite.
const rigsDb = new Database(path.resolve("./data.db"));
const fmtCT = (ms: number): string => {
  const p = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Chicago", year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23",
  }).formatToParts(new Date(ms));
  const g = (t: string) => p.find((x) => x.type === t)?.value ?? "00";
  return `${g("year")}-${g("month")}-${g("day")} ${g("hour")}:${g("minute")}:${g("second")}`;
};
let touchStmt: ReturnType<typeof rigsDb.prepare> | null = null;
function touchRigSession(sn: string, t: string): void {
  try {
    // Monotonic: only moves the timestamp forward. NOT LIKE '20%' catches
    // junk values in the old import (empty strings, literal "delete").
    touchStmt ??= rigsDb.prepare(
      `UPDATE rigs SET last_session_time=@t
       WHERE sn=@sn AND (last_session_time IS NULL OR last_session_time < @t OR last_session_time NOT LIKE '20%')`
    );
    touchStmt.run({ sn, t });
  } catch { /* best-effort; rigs table lives in data.db */ }
}
// One-shot backfill on boot: every rig we've seen connected since the live
// monitor started gets brought forward (idempotent — monotonic guard above).
try {
  for (const r of liveDb.prepare("SELECT sn, ts FROM live_latest WHERE ts IS NOT NULL").all() as { sn: string; ts: number }[])
    touchRigSession(r.sn, fmtCT(r.ts));
} catch { /* live_latest may be empty on first boot */ }

// ---------------- settings ----------------
function getSetting(key: string, dflt: string): string {
  const r = liveDb.prepare("SELECT value FROM live_settings WHERE key=?").get(key) as { value: string } | undefined;
  return r?.value ?? dflt;
}
function setSetting(key: string, value: string) {
  liveDb.prepare("INSERT INTO live_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(key, value);
}

// ---------------- poller state ----------------
type CycleInfo = { ts: number; polled: number; ok: number; failed: number; connected: number; moving: number; tookMs: number; dmsOnline: number | null; dmsTotal: number | null };
const DEFAULT_MAP_PUSH_URL = "https://dst-customer-system-map-production.up.railway.app/api/dms-live";
const DEFAULT_MAP_PUSH_TOKEN = "dst-dms-83a1439f5bf9d40c056fa3b969cb06cc";

const state = {
  running: getSetting("running", "0") === "1",
  intervalS: parseInt(getSetting("intervalS", "180"), 10),
  watchScope: getSetting("watchScope", "month") as "week" | "month" | "all",
  mapPushEnabled: getSetting("mapPushEnabled", "1") === "1",
  mapPushUrl: getSetting("mapPushUrl", DEFAULT_MAP_PUSH_URL),
  mapPushToken: getSetting("mapPushToken", DEFAULT_MAP_PUSH_TOKEN),
  lastPush: null as { ts: number; ok: boolean; status: number | string; rigs: number } | null,
  lastFaultPoll: 0,
  faultInfo: null as { ts: number; fetched: number; stored: number; ok?: boolean; error?: string | null } | null,
  panAuthDead: false,
  lastCycle: null as CycleInfo | null,
  cycleActive: false,
  sweep: { running: false, done: 0, total: 0, startedTs: 0 },
};

function watchlist(): string[] {
  let where = "worked_month=1";
  if (state.watchScope === "week") where = "worked_week=1";
  if (state.watchScope === "all") where = "1=1";
  const base = (db.prepare(`SELECT sn FROM rigs WHERE ${where}`).all() as { sn: string }[]).map((r) => r.sn);
  // always keep rigs that showed movement in the last 24h in the watchlist
  const hot = (
    liveDb.prepare("SELECT sn FROM live_latest WHERE moved=1 AND ts > ?").all(Date.now() - 24 * 3600e3) as { sn: string }[]
  ).map((r) => r.sn);
  return Array.from(new Set([...base, ...hot]));
}

function haversineM(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371000, toR = Math.PI / 180;
  const dLat = (lat2 - lat1) * toR, dLng = (lng2 - lng1) * toR;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * toR) * Math.cos(lat2 * toR) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

// ---- status sweep: official FJD Data Service API (signed, no cookies) ----
// One /device/realtimestatus call per SN returns connection state AND full
// live status, so the old two-phase DMS sweep (getVehicleInfoBySn +
// getStatusInfoBySn) collapses into a single phase.
const upsertConn = () =>
  liveDb.prepare(
    `INSERT INTO live_latest (sn, connected, conn_ts, moved) VALUES (?,?,?,0)
     ON CONFLICT(sn) DO UPDATE SET connected=excluded.connected, conn_ts=excluded.conn_ts,
       moved=CASE WHEN excluded.connected=1 THEN moved ELSE 0 END,
       online_since=CASE WHEN excluded.connected=1 THEN online_since ELSE NULL END`
  );

// Store one realtime-status result. Full row (history + rules + wake-edge)
// only for connected rigs; disconnected rigs just get the connection flag,
// matching the old two-phase behavior. Returns true when connected.
async function storeStatus(sn: string, d: FjdRealtime): Promise<boolean> {
  try {
    const connected = d.onlineStatus === "01" ? 1 : 0;
    const ts = Date.now();
    const prev = liveDb.prepare("SELECT lat, lng, ts, connected, online_since FROM live_latest WHERE sn=?").get(sn) as
      | { lat: number; lng: number; ts: number; connected: number; online_since: number | null }
      | undefined;
    if (!connected) {
      upsertConn().run(sn, 0, ts);
      clearSustain(sn); // rule state doesn't survive a disconnect
      return false;
    }
    let moved = 0;
    if (prev && d.lat != null && prev.lat != null) {
      if (haversineM(prev.lat, prev.lng, d.lat, d.lng!) > 5) moved = 1;
    }
    const row = {
      sn, ts,
      is_online: 1, work_status: d.workStatus != null ? parseInt(String(d.workStatus), 10) : null,
      lat: d.lat ?? null, lng: d.lng ?? null,
      speed_ms: d.speed ?? null, heading: d.direct != null ? parseFloat(String(d.direct)) : null,
      // rtk_status keeps the "4 = FIXED" semantics the alert rules were built
      // on, which maps to the official API's gpsWorkStatus (4 = fixed
      // solution). rtkMode is the differential SOURCE (0=base, 1=network,
      // 8=RTX), a different axis — not stored here.
      rtk_status: d.gpsWorkStatus ?? null, gps_work_status: d.gpsWorkStatus ?? null,
      satellites: d.searchStarCount ?? null, moved, connected: 1,
      // conn_ts = last time the API confirmed this rig connected. The Live
      // Monitor's status badge treats a rig as "Off" when conn_ts is older
      // than 30 min; the single-phase sweep never refreshed it for connected
      // rigs, so the KPI decayed to 2–4 "live" while 15 were really online.
      conn_ts: ts,
      // start of the current connect session — kept while the rig stays online
      online_since: prev?.connected === 1 && prev.online_since ? prev.online_since : ts,
    };
    liveDb
      .prepare(
        `INSERT INTO live_latest (sn,ts,is_online,work_status,lat,lng,speed_ms,heading,rtk_status,gps_work_status,satellites,moved,connected,conn_ts,online_since,prev_lat,prev_lng,prev_ts)
         VALUES (@sn,@ts,@is_online,@work_status,@lat,@lng,@speed_ms,@heading,@rtk_status,@gps_work_status,@satellites,@moved,@connected,@conn_ts,@online_since,@prev_lat,@prev_lng,@prev_ts)
         ON CONFLICT(sn) DO UPDATE SET ts=@ts,is_online=@is_online,work_status=@work_status,lat=@lat,lng=@lng,speed_ms=@speed_ms,
           heading=@heading,rtk_status=@rtk_status,gps_work_status=@gps_work_status,satellites=@satellites,moved=@moved,connected=@connected,
           conn_ts=@conn_ts,online_since=@online_since,prev_lat=@prev_lat,prev_lng=@prev_lng,prev_ts=@prev_ts`
      )
      .run({ ...row, prev_lat: prev?.lat ?? null, prev_lng: prev?.lng ?? null, prev_ts: prev?.ts ?? null });
    liveDb
      .prepare(
        `INSERT OR IGNORE INTO live_history (sn,ts,is_online,work_status,lat,lng,speed_ms,heading,rtk_status,gps_work_status,satellites,moved)
         VALUES (@sn,@ts,@is_online,@work_status,@lat,@lng,@speed_ms,@heading,@rtk_status,@gps_work_status,@satellites,@moved)`
      )
      .run({ sn: row.sn, ts: row.ts, is_online: row.is_online, work_status: row.work_status, lat: row.lat, lng: row.lng, speed_ms: row.speed_ms,
             heading: row.heading, rtk_status: row.rtk_status, gps_work_status: row.gps_work_status, satellites: row.satellites, moved: row.moved });
    // went_online: 0→1 connection transition this cycle. Rules can key on it
    // (e.g. to drive customer-outreach / AI triggers when a rig wakes up).
    touchRigSession(sn, fmtCT(ts)); // rig is online now — that's a session
    evaluateRules({ ...row, went_online: prev?.connected === 0 ? 1 : 0 });
    // Wake-edge: when a rig comes back online after being offline/stale, fetch
    // its steering parameters and evaluate parameter-based alert rules once.
    try {
      const { shouldFetchParams, lastFetchTs, onRigWake } = await import("./params");
      if (shouldFetchParams(sn, prev?.connected ?? null, 1, lastFetchTs(sn))) {
        void onRigWake(sn);
        // Also refresh the FJD Vehicle Profile Library — captures which tractor
        // the system is currently assigned to (brand/model + history).
        try {
          const { fetchVpForSn } = await import("./vpLibrary");
          void fetchVpForSn(sn).catch(() => null);
        } catch { /* vpLibrary optional */ }
      }
    } catch { /* params module optional at boot */ }
    return true;
  } catch {
    return false;
  }
}

// Best-effort cell/WiFi health for a connected rig, throttled per-SN so each
// rig costs at most ~4 extra API calls per hour.
const NET_REFRESH_MS = 15 * 60e3;
async function refreshNetwork(sn: string) {
  try {
    const prev = liveDb.prepare("SELECT net_ts FROM live_latest WHERE sn=?").get(sn) as { net_ts: number | null } | undefined;
    if (prev?.net_ts && Date.now() - prev.net_ts < NET_REFRESH_MS) return;
    const n = await fjdNetwork(sn);
    if (!n) return;
    liveDb
      .prepare("UPDATE live_latest SET net_mode=?, net_operator=?, net_rssi=?, net_ts=? WHERE sn=?")
      .run(n.netMode ?? null, n.operator ?? null, n.rssi ?? null, Date.now(), sn);
  } catch { /* network info is decoration, never fail the sweep */ }
}

async function statusSweep(
  sns: string[],
  concurrency = 16,
  onProgress?: (done: number) => void
): Promise<{ ok: number; failed: number; connected: string[] }> {
  let i = 0, ok = 0, done = 0, failed = 0;
  const connected: string[] = [];
  async function worker() {
    while (i < sns.length) {
      const sn = sns[i++];
      // One retry on a null answer (timeout / transient API error). Without
      // it a flaky cycle answered for only a handful of rigs and the Live
      // Monitor flashed "4 live" while the map (fed from live_latest, which
      // keeps the last good row) still showed 14–15.
      let d = await fjdRealtimeStatus(sn);
      if (!d) {
        await new Promise((r) => setTimeout(r, 400));
        d = await fjdRealtimeStatus(sn);
      }
      if (d) {
        ok++;
        if (await storeStatus(sn, d)) {
          connected.push(sn);
          await refreshNetwork(sn);
        }
      } else {
        failed++;
      }
      done++;
      onProgress?.(done);
    }
  }
  await Promise.all(Array.from({ length: concurrency }, worker));
  return { ok, failed, connected };
}

// ---------------- daily work stats (acreage rollups) ----------------
// Pulls /device/operationStats for rigs seen online in the last 48h, for
// today + yesterday (Central time), every ~3h. Yesterday is re-pulled so
// jobs that close out overnight get their final acreage.
function dayCT(offsetDays = 0): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "America/Chicago", year: "numeric", month: "2-digit", day: "2-digit" })
    .format(new Date(Date.now() - offsetDays * 86400e3));
}
const workCollect = {
  running: false,
  lastTs: parseInt(getSetting("workCollectTs", "0"), 10) || (null as number | null),
  lastRigs: 0,
};

export async function collectWorkStats(): Promise<{ rigs: number } | null> {
  if (workCollect.running) return null;
  workCollect.running = true;
  try {
    const sns = (liveDb
      .prepare("SELECT sn FROM live_latest WHERE ts > ?")
      .all(Date.now() - 48 * 3600e3) as { sn: string }[]).map((r) => r.sn);
    const days = [dayCT(0), dayCT(1)];
    const up = liveDb.prepare(
      `INSERT INTO work_days (sn,day,batch_count,total_area_mu,total_time_h,auto_area_mu,manual_area_mu,open_batches,fetched_ts)
       VALUES (?,?,?,?,?,?,?,?,?)
       ON CONFLICT(sn,day) DO UPDATE SET batch_count=excluded.batch_count,total_area_mu=excluded.total_area_mu,
         total_time_h=excluded.total_time_h,auto_area_mu=excluded.auto_area_mu,manual_area_mu=excluded.manual_area_mu,
         open_batches=excluded.open_batches,fetched_ts=excluded.fetched_ts`
    );
    let touched = 0, i = 0;
    async function worker() {
      while (i < sns.length) {
        const sn = sns[i++];
        for (const day of days) {
          try {
            const d: any = await fjdOperationStats(sn, day);
            if (!d || !d.batchCount) continue;
            const recs: any[] = await allDailyRecords(sn, day, d);
            storeSessions(sn, day, recs);
            const sum = (k: string) => {
              let s = 0, has = false;
              for (const r of recs) if (r[k] != null) { s += r[k]; has = true; }
              return has ? s : null;
            };
            up.run(
              sn, day, d.batchCount ?? 0,
              d.totalArea ?? sum("workArea"), d.totalTime ?? null,
              sum("autoArea"), sum("manualArea"),
              recs.filter((r) => r.status !== 2).length, // status 2 = job closed
              Date.now()
            );
            touched++;
            // A recorded work day is a session even if we missed the rig live.
            touchRigSession(sn, day === days[0] ? fmtCT(Date.now()) : `${day} 23:59:59`);
          } catch { /* per-rig failures don't stop the pass */ }
        }
      }
    }
    await Promise.all(Array.from({ length: 8 }, worker));
    refreshActivityFlags();
    workCollect.lastTs = Date.now();
    workCollect.lastRigs = touched;
    setSetting("workCollectTs", String(workCollect.lastTs));
    return { rigs: touched };
  } finally {
    workCollect.running = false;
  }
}

// ---------------- sessions feed (official API → data.db sessions) ----------------
// The `sessions` table was a one-shot cookie-DMS import frozen at 2026-07-21.
// Overview's "work sessions per day", the Daily Report's rig picker, Rigs
// activity flags and walk-day lists all read it, so every one of them went
// stale together. operationStats already returns the per-job records for
// each rig-day we pull for acreage; store them here so the table stays live.
// Units match the old import: work_area in mu, work_time in hours, width in m.
// Column-aware so a schema drift in data.db can't crash the server at boot.
const SESSION_COLS = new Set((rigsDb.prepare("PRAGMA table_info(sessions)").all() as { name: string }[]).map((c) => c.name));
const SESSION_FIELDS = ["sn", "work_no", "work_name", "create_time", "end_time", "width", "work_area", "app_calc_area", "work_time", "status", "work_type"].filter((c) => SESSION_COLS.has(c));
let upsertSession: ReturnType<typeof rigsDb.prepare> | null = null;
let deleteSession: ReturnType<typeof rigsDb.prepare> | null = null;
let insertSession: ReturnType<typeof rigsDb.prepare> | null = null;
try {
  if (SESSION_COLS.has("sn") && SESSION_COLS.has("work_no")) {
    const cols = SESSION_FIELDS.join(", ");
    const vals = SESSION_FIELDS.map((c) => `@${c}`).join(", ");
    const upd = SESSION_FIELDS.filter((c) => !["sn", "work_no", "create_time"].includes(c)).map((c) => `${c}=COALESCE(excluded.${c}, sessions.${c})`).join(", ");
    try {
      rigsDb.exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_sessions_sn_workno ON sessions(sn, work_no)");
      upsertSession = rigsDb.prepare(`INSERT INTO sessions (${cols}) VALUES (${vals}) ON CONFLICT(sn, work_no) DO UPDATE SET ${upd}`);
    } catch (e) {
      // duplicates in the legacy import → fall back to delete+insert
      console.warn("[sessions] unique index unavailable, using delete+insert:", (e as Error).message);
      deleteSession = rigsDb.prepare("DELETE FROM sessions WHERE sn=? AND work_no=?");
      insertSession = rigsDb.prepare(`INSERT INTO sessions (${cols}) VALUES (${vals})`);
    }
  } else {
    console.error("[sessions] sessions table missing sn/work_no — feed disabled");
  }
} catch (e) {
  console.error("[sessions] init failed — feed disabled", (e as Error).message);
}
const storeSessionsTx = rigsDb.transaction((sn: string, day: string, recs: any[]) => {
  if (!upsertSession && !insertSession) return 0;
  let n = 0;
  for (const r of recs) {
    if (!r?.workNo) continue;
    // Keep create_time on the day the API bucketed the job under, so
    // substr(create_time,1,10) groupings agree with the FJD day boundary.
    const start = typeof r.startTime === "string" && r.startTime.length >= 19 ? r.startTime : `${day} 00:00:00`;
    const row: Record<string, unknown> = {
      sn, work_no: String(r.workNo), work_name: r.workName ?? null,
      create_time: start.startsWith(day) ? start : `${day} ${start.slice(11, 19) || "00:00:00"}`,
      end_time: typeof r.endTime === "string" && r.endTime.length >= 19 ? r.endTime : null,
      width: r.workWidth != null ? Number(r.workWidth) : null,
      work_area: r.workArea != null ? Number(r.workArea) : null,
      app_calc_area: r.preciseArea != null ? Number(r.preciseArea) : null,
      work_time: r.workTotalTime != null ? Math.round((Number(r.workTotalTime) / 3600) * 100) / 100 : null,
      status: r.status != null ? Number(r.status) : null,
      work_type: r.workType != null ? String(r.workType) : (r.workMode ?? null),
    };
    const params: Record<string, unknown> = {};
    for (const c of SESSION_FIELDS) params[c] = row[c] ?? null;
    if (upsertSession) upsertSession.run(params);
    else { deleteSession!.run(sn, String(r.workNo)); insertSession!.run(params); }
    n++;
  }
  return n;
});
export function storeSessions(sn: string, day: string, recs: any[]): number {
  try { return storeSessionsTx(sn, day, recs); } catch (e) { console.error("[sessions] store failed", sn, day, (e as Error).message); return 0; }
}
// operationStats pages its job list (pageSize 50 in fjdApi). Fetch the rest
// when a rig logged more than one page of jobs in a day (rare but real).
async function allDailyRecords(sn: string, day: string, first: any): Promise<any[]> {
  const recs: any[] = [...(first?.dailyRecords?.records ?? [])];
  const total = Number(first?.dailyRecords?.total ?? recs.length);
  let page = 2;
  while (recs.length < total && page <= 6) {
    const d: any = await fjdOperationStats(sn, day, page++);
    const more: any[] = d?.dailyRecords?.records ?? [];
    if (!more.length) break;
    recs.push(...more);
  }
  return recs;
}
// Recompute the Rigs-page activity columns from the now-live sessions table.
// (They were static columns from the Jul 21 import.) Central-time day edges.
export function refreshActivityFlags(): void {
  try {
    const today = dayCT(0), week = dayCT(6), month = dayCT(29);
    rigsDb.exec("BEGIN");
    rigsDb.prepare(
      `UPDATE rigs SET
         total_sessions = (SELECT COUNT(*) FROM sessions s WHERE s.sn = rigs.sn),
         worked_today = EXISTS(SELECT 1 FROM sessions s WHERE s.sn = rigs.sn AND s.create_time >= @today),
         worked_week  = EXISTS(SELECT 1 FROM sessions s WHERE s.sn = rigs.sn AND s.create_time >= @week),
         worked_month = EXISTS(SELECT 1 FROM sessions s WHERE s.sn = rigs.sn AND s.create_time >= @month),
         last_session_time = COALESCE((SELECT MAX(create_time) FROM sessions s WHERE s.sn = rigs.sn AND s.create_time LIKE '20%'), last_session_time)`
    ).run({ today, week, month });
    rigsDb.exec("COMMIT");
  } catch (e) {
    try { rigsDb.exec("ROLLBACK"); } catch { /* not in tx */ }
    console.error("[sessions] activity flag refresh failed", (e as Error).message);
  }
}
export function sessionsHealth() {
  const r = rigsDb.prepare("SELECT MAX(create_time) latest, COUNT(*) total FROM sessions").get() as { latest: string | null; total: number };
  const last7 = rigsDb.prepare("SELECT COUNT(*) c FROM sessions WHERE create_time >= ?").get(dayCT(6)) as { c: number };
  return { latest: r.latest, total: r.total, last7d: last7.c, backfill: backfill.status };
}
// One-shot gap backfill (Jul 22 → yesterday) so charts and daily reports
// aren't blank for the weeks the table sat frozen. Runs in the background at
// modest concurrency; idempotent (upsert) and remembered in live_settings so
// it never re-runs on restart. For days covered by work_days we only ask the
// API about rigs known to have worked; earlier days sweep the whole roster.
const backfill = { status: { running: false, day: null as string | null, done: 0, total: 0, calls: 0, finishedTs: parseInt(getSetting("sessionsBackfillDone", "0"), 10) || null } };
export async function backfillSessions(fromDay = "2026-07-22"): Promise<void> {
  if (backfill.status.running || backfill.status.finishedTs) return;
  backfill.status.running = true;
  try {
    const roster = (rigsDb.prepare("SELECT sn FROM rigs WHERE sn LIKE 'FJ%'").all() as { sn: string }[]).map((r) => r.sn);
    const firstWorkDay = (liveDb.prepare("SELECT MIN(day) d FROM work_days").get() as { d: string | null }).d;
    const days: string[] = [];
    for (let d = new Date(`${fromDay}T12:00:00Z`); ; d.setUTCDate(d.getUTCDate() + 1)) {
      const s = d.toISOString().slice(0, 10);
      if (s >= dayCT(0)) break;
      days.push(s);
    }
    backfill.status.total = days.length;
    for (const day of days) {
      backfill.status.day = day;
      let sns = roster;
      if (firstWorkDay && day >= firstWorkDay) {
        sns = (liveDb.prepare("SELECT sn FROM work_days WHERE day=? AND batch_count>0").all(day) as { sn: string }[]).map((r) => r.sn);
      }
      let i = 0;
      const worker = async () => {
        while (i < sns.length) {
          const sn = sns[i++];
          try {
            backfill.status.calls++;
            const d: any = await fjdOperationStats(sn, day);
            if (!d || !d.batchCount) continue;
            storeSessions(sn, day, await allDailyRecords(sn, day, d));
          } catch { /* per-rig failures don't stop the pass */ }
        }
      };
      await Promise.all(Array.from({ length: 6 }, worker));
      backfill.status.done++;
    }
    refreshActivityFlags();
    backfill.status.finishedTs = Date.now();
    setSetting("sessionsBackfillDone", String(backfill.status.finishedTs));
    console.log(`[sessions] backfill complete: ${days.length} days, ${backfill.status.calls} API calls`);
  } catch (e) {
    console.error("[sessions] backfill failed", (e as Error).message);
  } finally {
    backfill.status.running = false;
    backfill.status.day = null;
  }
}

export function workDays(daysBack = 30) {
  const since = dayCT(daysBack);
  const rows = liveDb
    .prepare("SELECT * FROM work_days WHERE day >= ? ORDER BY day DESC, total_time_h DESC")
    .all(since) as any[];
  const sns = [...new Set(rows.map((r) => r.sn))];
  const rigMap = new Map<string, any>();
  const contactMap = new Map<string, any>();
  if (sns.length) {
    const ph = sns.map(() => "?").join(",");
    for (const r of db
      .prepare(`SELECT sn, device_name, model, customer_contact FROM rigs WHERE sn IN (${ph})`)
      .all(...sns) as any[]) rigMap.set(r.sn, r);
    for (const r of liveDb
      .prepare(`SELECT sn, name, hubspot_contact_link FROM serial_contacts WHERE sn IN (${ph})`)
      .all(...sns) as any[]) contactMap.set(r.sn, r);
  }
  return {
    lastCollect: workCollect.lastTs,
    running: workCollect.running,
    rows: rows.map((r) => ({
      ...r,
      rig: rigMap.get(r.sn) ?? null,
      customer_name: contactMap.get(r.sn)?.name ?? rigMap.get(r.sn)?.customer_contact ?? null,
      hubspot_contact_link: contactMap.get(r.sn)?.hubspot_contact_link ?? null,
    })),
  };
}

export function collectWorkNow(): { started: boolean } {
  if (workCollect.running) return { started: false };
  void collectWorkStats();
  return { started: true };
}

// DMS dealer dashboard fleet-wide online count (covers ALL device types incl.
// AT1/AS2/AG1 units that the per-SN remoteDebug endpoint can't see).
async function fetchDmsOverview(): Promise<{ online: number; total: number } | null> {
  try {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 12000);
    const res = await fetch(`${PAN_BASE}/at2-api/dealerDashboard/overview`, {
      method: "POST",
      headers: { ...panHeaders(), "content-type": "application/json" },
      body: JSON.stringify({ dealerCode: "C2200046" }),
      signal: ctl.signal,
    });
    clearTimeout(t);
    state.panAuthDead = res.status === 401;
    if (!res.ok) return null;
    const j: any = await res.json();
    const d = j?.data;
    if (!d || typeof d.onlineCount !== "number") return null;
    return { online: d.onlineCount, total: d.totalCount ?? null };
  } catch {
    return null;
  }
}

// ---------------- DMS fault polling ----------------
// dealerDashboard/fault/details caps each query at 3 days; poll the trailing
// 3-day window every 30 min and accumulate history locally. First run
// backfills 30 days in 3-day chunks.
const FAULT_POLL_MS = 30 * 60e3;
const upsertFault = liveDb.prepare(`
  INSERT INTO dms_faults (sn, create_ts, fault_code, fault_name, fault_content, handling_advice, error_category, upload_ts)
  VALUES (?,?,?,?,?,?,?,?)
  ON CONFLICT(sn, create_ts, fault_code) DO UPDATE SET
    fault_name=excluded.fault_name, fault_content=excluded.fault_content,
    handling_advice=excluded.handling_advice, error_category=excluded.error_category, upload_ts=excluded.upload_ts
`);

async function fetchFaultChunk(startTime: number, endTime: number): Promise<any[]> {
  const out: any[] = [];
  for (let pageNum = 1; pageNum <= 10; pageNum++) {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 15000);
    const res = await fetch(`${PAN_BASE}/at2-api/dealerDashboard/fault/details`, {
      method: "POST",
      headers: { ...panHeaders(), "content-type": "application/json" },
      body: JSON.stringify({ dealerCode: "C2200046", dealerBrand: "FJD", startTime, endTime, type: 0, pageNum, pageSize: 500 }),
      signal: ctl.signal,
    });
    clearTimeout(t);
    if (res.status === 401) { state.panAuthDead = true; throw new Error("DMS portal token rejected (401) — set a fresh PAN_AUTH / panAuth"); }
    if (!res.ok) break;
    const j: any = await res.json();
    const rows = Array.isArray(j?.data) ? j.data : [];
    out.push(...rows);
    if (out.length >= (j?.count ?? 0) || rows.length === 0) break;
  }
  return out;
}

async function pollFaults() {
  const now = Date.now();
  if (now - state.lastFaultPoll < FAULT_POLL_MS) return;
  state.lastFaultPoll = now;
  try {
    const day = 86400e3;
    const backfilled = getSetting("faultBackfillDone", "0") === "1";
    const chunks: Array<[number, number]> = [];
    if (!backfilled) {
      for (let i = 0; i < 10; i++) chunks.push([now - (i + 1) * 3 * day + 1, now - i * 3 * day]);
    } else {
      chunks.push([now - 3 * day + 1, now]);
    }
    let fetched = 0, stored = 0;
    for (const [s, e] of chunks) {
      const rows = await fetchFaultChunk(s, e);
      fetched += rows.length;
      for (const f of rows) {
        if (!f?.deviceSn || !f?.createTimeStamp) continue;
        const r = upsertFault.run(
          String(f.deviceSn), Number(f.createTimeStamp), String(f.faultCode ?? ""),
          f.faultName ?? null, f.faultContent ?? null, f.handlingAdvice ?? null,
          Number.isFinite(f.errorCategory) ? f.errorCategory : null,
          f.uploadTimeStamp ? Number(f.uploadTimeStamp) : null,
        );
        stored += r.changes;
      }
    }
    if (!backfilled) setSetting("faultBackfillDone", "1");
    liveDb.prepare("DELETE FROM dms_faults WHERE create_ts < ?").run(now - 60 * day);
    state.faultInfo = { ts: now, fetched, stored, ok: true, error: null };
  } catch (e) {
    state.faultInfo = { ts: now, fetched: -1, stored: -1, ok: false, error: (e as Error).message };
  }
}

export function recentFaults(days = 14, limit = 800) {
  return liveDb
    .prepare(
      `SELECT sn, create_ts AS ts, fault_code AS code, fault_name AS name,
              fault_content AS content, handling_advice AS advice, error_category AS category
       FROM dms_faults WHERE create_ts > ? ORDER BY create_ts DESC LIMIT ?`,
    )
    .all(Date.now() - days * 86400e3, limit);
}

// Push the latest live snapshot to the DST Customer System Map app so DMS-live
// rigs can be compared against GEODNET RTK-live rovers on the map.

function openAlertsForPush() {
  // "Open" now means unresolved (the condition is still live), not un-acked.
  // fired_ts / last_seen_ts ride along so the map can show timestamps + duration.
  const rows = liveDb.prepare(
    `SELECT e.id, e.sn, e.ts, e.ts AS fired_ts, e.last_seen_ts, e.message,
            COALESCE(e.reviewed,0) AS reviewed, COALESCE(e.contacted,0) AS contacted
       FROM alert_events e
      WHERE e.resolved_ts IS NULL
      ORDER BY e.ts DESC LIMIT 200`
  ).all() as any[];
  // Precompute duration_min (fired -> last_seen | now) so the map can render it
  // directly without recomputing. The map also has a local fallback.
  const now = Date.now();
  return rows.map((e) => ({
    ...e,
    duration_min: e.ts ? Math.max(0, Math.round(((e.last_seen_ts ?? now) - e.ts) / 60000)) : null,
  }));
}

// Current Cloudflare quick-tunnel URL, written by the com.dst.fleet-tunnel
// launchd job next to the data dir. Rides along in the map push so the map
// app can serve a stable /fleet redirect.
function currentTunnelUrl(): string | null {
  const fs = require("fs"); const path = require("path");
  const candidates = [
    process.env.FLEET_TUNNEL_URL_FILE,
    path.join(process.cwd(), "tunnel-url.txt"),
    path.join(__dirname, "..", "tunnel-url.txt"), // dist/ -> app root
  ].filter(Boolean) as string[];
  for (const f of candidates) {
    try {
      const u = fs.readFileSync(f, "utf8").trim();
      if (/^https:\/\/[a-z0-9-]+\.trycloudflare\.com$/.test(u)) return u;
    } catch { /* next */ }
  }
  return null;
}

// Assemble the same body the push sends, so a pull hits an identical shape.
// Extracted so the pull endpoint and the periodic push share one source of truth.
export function dmsLiveSnapshot() {
  const board = liveBoard() as any[];
  const rigs = board
    .filter((r) => r.connected === 1)
    .map((r) => ({
      sn: r.sn, ts: r.ts, conn_ts: r.conn_ts,
      lat: r.lat, lng: r.lng, speed_mph: r.speed_mph, heading: r.heading,
      moved: r.moved, satellites: r.satellites, rtk_status: r.rtk_status, work_status: r.work_status,
      net_mode: r.net_mode ?? null, net_operator: r.net_operator ?? null, net_rssi: r.net_rssi ?? null,
      device_name: r.rig?.device_name ?? null, model: r.rig?.model ?? null,
      machine_class: r.rig?.machine_class ?? null, brand: r.rig?.brand_normalized ?? null,
      customer_email: r.rig?.customer_email ?? null, customer_contact: r.rig?.customer_contact ?? null,
      customer_name: r.customer?.customer_name ?? null, hubspot_link: r.customer?.hubspot_link ?? null,
      contact_name: r.contact?.name ?? null, phone: r.contact?.phone ?? null,
      hubspot_contact_link: r.contact?.hubspot_contact_link ?? null,
      hubspot_deal_link: r.contact?.hubspot_deal_link ?? null,
      city: r.rig?.city ?? null, province: r.rig?.province ?? null,
    }));
  const connectedSns = new Set(rigs.map((r) => String(r.sn || "").trim()));
  const alerts = openAlertsForPush().filter((a: any) =>
    connectedSns.has(String(a.sn || "").trim())
  );
  return {
    source: "dst-fleet-reports",
    ts: Date.now(),
    cycle: state.lastCycle,
    rigs,
    faults: recentFaults(),
    alerts,
    fleetUrl: currentTunnelUrl(),
  };
}

// Auth guard for the pull endpoint. Reuses the map push token so ops stays
// symmetric — no new secret to manage. Accepts the token via three channels
// because trycloudflare (and Cloudflare Access in general) STRIPS incoming
// `Authorization` headers, which broke pull-through-tunnel:
//   1. `Authorization: Bearer <token>` — normal path (works on loopback / direct)
//   2. `X-DMS-Token: <token>` — custom header, passes through Cloudflare intact
//   3. `?token=<token>` — query-string fallback for constrained clients
// Callers must present the exact same token the fleet uses to push.
export function verifyMapPullAuth(opts: {
  authorization?: string | string[] | undefined;
  xDmsToken?: string | string[] | undefined;
  queryToken?: string | string[] | undefined;
}): boolean {
  if (!state.mapPushToken) return false;
  const want = state.mapPushToken;
  const auth = String(opts.authorization || "");
  if (auth === `Bearer ${want}`) return true;
  const xdt = Array.isArray(opts.xDmsToken) ? opts.xDmsToken[0] : opts.xDmsToken;
  if (xdt && String(xdt) === want) return true;
  const qt = Array.isArray(opts.queryToken) ? opts.queryToken[0] : opts.queryToken;
  if (qt && String(qt) === want) return true;
  return false;
}

// Read-only view of the map push endpoint + shared token, for other modules
// (setups.ts fetches the map's /api/fleet/tractors with the same secret).
export function mapPushConfig(): { url: string; token: string } {
  return { url: state.mapPushUrl, token: state.mapPushToken };
}

/** Push the current DMS-live snapshot to the map right now (after a manual customer link). */
export async function pushToMapNow(): Promise<void> { await pushToMap(); }

async function pushToMap() {
  if (!state.mapPushEnabled || !state.mapPushUrl) return;
  try {
    // Only push alerts whose rig is currently connected. Alerts stay open in
    // the DB (they're not "resolved" — the rig just went quiet), but the map
    // Farmers-in-the-Field panel is a live view, so a row with no live rig to
    // click through to is noise. When the rig reconnects the alert reappears
    // on the next push. Reviewed/Contacted acks and history remain in the DB
    // and re-emerge alongside the rig.
    const body = dmsLiveSnapshot();
    const rigs = body.rigs;
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 15000);
    const res = await fetch(state.mapPushUrl, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${state.mapPushToken}` },
      body: JSON.stringify(body),
      signal: ctl.signal,
    });
    clearTimeout(t);
    state.lastPush = { ts: Date.now(), ok: res.ok, status: res.status, rigs: rigs.length };
    // The map returns triage checkmarks users clicked since the last cycle.
    // Persist them here so the fleet DB stays the source of truth.
    if (res.ok) {
      try {
        const reply = (await res.json()) as { acks?: { id?: number; reviewed?: boolean; contacted?: boolean }[] };
        if (Array.isArray(reply?.acks)) {
          const upd = liveDb.prepare("UPDATE alert_events SET reviewed=?, contacted=? WHERE id=? AND ack_ts IS NULL");
          for (const a of reply.acks) {
            if (Number.isFinite(Number(a?.id))) upd.run(a.reviewed ? 1 : 0, a.contacted ? 1 : 0, Number(a.id));
          }
        }
      } catch (_) { /* non-JSON reply from older map build */ }
    }
  } catch (e) {
    state.lastPush = { ts: Date.now(), ok: false, status: (e as Error).name === "AbortError" ? "timeout" : "error", rigs: 0 };
  }
}

let timer: ReturnType<typeof setTimeout> | null = null;

async function cycle() {
  if (state.cycleActive) return;
  state.cycleActive = true;
  const started = Date.now();
  try {
    // Single-phase sweep across the whole fleet via the official API —
    // each call returns connection state AND full status in one shot.
    const sns = (db.prepare("SELECT sn FROM rigs").all() as { sn: string }[]).map((r) => r.sn);
    const [sweep, overview] = await Promise.all([statusSweep(sns), fetchDmsOverview()]);
    // A rig that stopped answering the API for over an hour (every retry
    // failed) is treated as offline so a dead poll can't leave it "live" forever.
    liveDb.prepare("UPDATE live_latest SET connected=0, moved=0, online_since=NULL WHERE connected=1 AND ts < ?").run(started - 60 * 60e3);
    const moving = (liveDb.prepare("SELECT COUNT(*) c FROM live_latest WHERE moved=1 AND ts > ?").get(started) as { c: number }).c;
    // Live count comes from live_latest (same table the Customer System Map
    // push reads), not from "rigs that answered this cycle" — so Fleet and
    // the map agree even when some polls time out.
    const liveNow = (liveDb.prepare("SELECT COUNT(*) c FROM live_latest WHERE connected=1").get() as { c: number }).c;
    state.lastCycle = {
      ts: Date.now(), polled: sns.length, ok: sweep.ok, failed: sweep.failed, connected: liveNow, moving,
      tookMs: Date.now() - started,
      dmsOnline: overview?.online ?? null, dmsTotal: overview?.total ?? null,
    };
    // Resolve open alerts for rigs that just went (or stayed) offline. Runs
    // after the sweep refreshed every rig's `connected` flag, so "offline"
    // reflects this cycle. This is what finally clears a rig's alert once it
    // powers down instead of leaving it stuck open (the Bill Englert bug).
    const offResolved = resolveOfflineAlerts();
    if (offResolved) console.log(`alerts: auto-resolved ${offResolved} (system offline).`);
    // prune history older than 14 days
    liveDb.prepare("DELETE FROM live_history WHERE ts < ?").run(Date.now() - 14 * 86400e3);
    await pollFaults();
    // acreage rollups + sessions feed every ~3h, piggybacked on the cycle
    if (!workCollect.running && Date.now() - (workCollect.lastTs ?? 0) > 3 * 3600e3) void collectWorkStats();
    // one-shot gap backfill of the sessions table (no-op once finished)
    void backfillSessions();
    void pushToMap();
  } finally {
    state.cycleActive = false;
    schedule();
  }
}

function schedule() {
  if (timer) clearTimeout(timer);
  if (!state.running) return;
  timer = setTimeout(cycle, state.intervalS * 1000);
}

export function configureLive(opts: {
  running?: boolean; intervalS?: number; watchScope?: string;
  mapPushEnabled?: boolean; mapPushUrl?: string; mapPushToken?: string; panAuth?: string;
}) {
  if (opts.mapPushEnabled !== undefined) {
    state.mapPushEnabled = opts.mapPushEnabled;
    setSetting("mapPushEnabled", opts.mapPushEnabled ? "1" : "0");
  }
  if (typeof opts.mapPushUrl === "string") {
    state.mapPushUrl = opts.mapPushUrl.trim();
    setSetting("mapPushUrl", state.mapPushUrl);
  }
  if (typeof opts.mapPushToken === "string") {
    state.mapPushToken = opts.mapPushToken.trim();
    setSetting("mapPushToken", state.mapPushToken);
  }
  if (typeof opts.panAuth === "string" && opts.panAuth.trim()) {
    // Fresh dealer-portal token pasted from a logged-in DMS session. Reset the
    // dead flag and the fault poll timer so the next cycle retries immediately.
    setSetting("panAuth", opts.panAuth.trim());
    state.panAuthDead = false;
    state.lastFaultPoll = 0;
  }
  if (opts.running !== undefined) {
    state.running = opts.running;
    setSetting("running", opts.running ? "1" : "0");
    if (opts.running && !state.cycleActive) void cycle();
    if (!opts.running && timer) clearTimeout(timer);
  }
  if (opts.intervalS && opts.intervalS >= 60) {
    state.intervalS = opts.intervalS;
    setSetting("intervalS", String(opts.intervalS));
    schedule();
  }
  if (opts.watchScope && ["week", "month", "all"].includes(opts.watchScope)) {
    state.watchScope = opts.watchScope as typeof state.watchScope;
    setSetting("watchScope", opts.watchScope);
  }
}

export function sweepAll(): boolean {
  if (state.sweep.running) return false;
  const sns = (db.prepare("SELECT sn FROM rigs").all() as { sn: string }[]).map((r) => r.sn);
  state.sweep = { running: true, done: 0, total: sns.length, startedTs: Date.now() };
  void statusSweep(sns, 20, (done) => (state.sweep.done = done)).finally(() => {
    state.sweep.running = false;
  });
  return true;
}

export function liveState() {
  return {
    running: state.running,
    fjdApiConfigured: fjdConfigured(),
    intervalS: state.intervalS,
    watchScope: state.watchScope,
    cycleActive: state.cycleActive,
    lastCycle: state.lastCycle,
    sweep: state.sweep,
    mapPush: { enabled: state.mapPushEnabled, url: state.mapPushUrl, tokenSet: !!state.mapPushToken, last: state.lastPush },
    faults: state.faultInfo,
    panAuthDead: state.panAuthDead,
    faultsLatest: (liveDb.prepare("SELECT MAX(create_ts) m FROM dms_faults").get() as { m: number | null }).m,
    sessions: sessionsHealth(),
    watching: watchlist().length,
    openAlerts: (liveDb.prepare("SELECT COUNT(*) c FROM alert_events WHERE ack_ts IS NULL").get() as { c: number }).c,
  };
}

// ---------------- alert rules ----------------
// field values derived from a snapshot row
export const RULE_FIELDS: Record<string, { label: string; unit?: string; derive: (r: any) => number | null }> = {
  speed_mph: { label: "Speed", unit: "mph", derive: (r) => (r.speed_ms != null ? r.speed_ms * 2.23694 : null) },
  satellites: { label: "Satellites", derive: (r) => r.satellites },
  rtk_status: { label: "RTK status code (4=FIXED)", derive: (r) => r.rtk_status },
  gps_work_status: { label: "GPS work status (4=RTK FIXED)", derive: (r) => r.gps_work_status },
  work_status: { label: "Work status code", derive: (r) => r.work_status },
  moved: { label: "Moved since last poll (0/1)", derive: (r) => r.moved },
  connected: { label: "Terminal connected (0/1)", derive: (r) => r.connected },
  is_online: { label: "DMS is_online flag (0/1)", derive: (r) => r.is_online },
  went_online: { label: "Came online this cycle (0/1)", derive: (r) => r.went_online ?? 0 },
  online_minutes: {
    label: "Online duration (min since terminal connect)",
    unit: "min",
    derive: (r) => (r.connected === 1 && r.online_since ? (Date.now() - r.online_since) / 60000 : null),
  },
  stale_minutes: {
    label: "Stale minutes (since last DMS update)",
    unit: "min",
    derive: (r) => (r.ts ? Math.floor((Date.now() - r.ts) / 60000) : null),
  },
  // Fault-based rule: fires when ANY new fault matching this severity appears
  // in the last 24h. value = error_category code from DMS (1=info, 2=warn, 3=error).
  fault_severity: {
    label: "Fault severity in last 24h (>= value)",
    derive: (r) => {
      const row = liveDb
        .prepare(
          `SELECT MAX(error_category) AS m FROM dms_faults
           WHERE sn=? AND create_ts > ?`,
        )
        .get(r.sn, Date.now() - 24 * 3600e3) as { m: number | null } | undefined;
      return row?.m ?? null;
    },
  },
  fault_count_24h: {
    label: "Fault count in last 24h",
    derive: (r) => {
      const row = liveDb
        .prepare(
          `SELECT COUNT(*) AS c FROM dms_faults
           WHERE sn=? AND create_ts > ?`,
        )
        .get(r.sn, Date.now() - 24 * 3600e3) as { c: number };
      return row?.c ?? 0;
    },
  },
};

// Params module, loaded lazily to avoid an import cycle (params.ts imports
// liveDb from this file). Ready well before the first sweep evaluates rules.
let paramsMod: typeof import("./params") | null = null;
void import("./params").then((m) => { paramsMod = m; }).catch(() => null);

export type RuleCond = { field: string; op: string; value: number; value2?: number | null };

// A rule's conditions: the JSON array when present, else the legacy single
// field/op/value columns. All conditions must match (AND).
function ruleConds(rule: any): RuleCond[] {
  if (rule.conditions) {
    try {
      const arr = JSON.parse(rule.conditions);
      if (Array.isArray(arr) && arr.length) return arr;
    } catch { /* fall back to legacy columns */ }
  }
  return [{ field: rule.field, op: rule.op, value: rule.value, value2: rule.value2 }];
}

// Current value + display label for one condition. Live fields come off the
// row; param.* fields come from the dms_params cache (refreshed on every rig
// wake, ≤24h old) converted to imperial — same units the rules are entered in.
function condEval(c: RuleCond, row: any): { v: number | null; label: string } {
  if (c.field.startsWith("param.")) {
    const pf = c.field.slice("param.".length);
    const meta = paramsMod?.PARAM_CATALOG.find((p) => p.field === pf);
    const label = meta?.label ?? pf;
    const raw = paramsMod?.getParams(row.sn)?.[pf];
    if (raw == null) return { v: null, label };
    const n = typeof raw === "number" ? raw : parseFloat(String(raw));
    if (!Number.isFinite(n)) return { v: null, label };
    return { v: paramsMod!.toImperial(meta?.unit ?? null, n).value, label };
  }
  const f = RULE_FIELDS[c.field];
  if (!f) return { v: null, label: c.field };
  return { v: f.derive(row), label: f.label };
}

function condHit(c: RuleCond, v: number): boolean {
  switch (c.op) {
    case "gt": return v > c.value;
    case "lt": return v < c.value;
    case "eq": return v === c.value;
    case "ne": return v !== c.value;
    case "between": return v >= c.value && v <= (c.value2 ?? c.value);
    case "outside": return v < c.value || v > (c.value2 ?? c.value);
    default: return false;
  }
}

// Sustain tracker: when each (rule, sn) first went true, cleared the moment it
// breaks or the rig disconnects. In-memory — a restart just restarts the clock.
const sustainSince = new Map<string, number>();
function clearSustain(sn: string) {
  const suffix = `:${sn}`;
  for (const k of sustainSince.keys()) if (k.endsWith(suffix)) sustainSince.delete(k);
}

// Prepared once: open-event lifecycle statements. "Open" = resolved_ts IS NULL.
const findOpenEvent = liveDb.prepare(
  "SELECT id FROM alert_events WHERE rule_id=? AND sn=? AND resolved_ts IS NULL ORDER BY ts DESC LIMIT 1"
);
const touchOpenEvent = liveDb.prepare(
  "UPDATE alert_events SET last_seen_ts=?, message=?, value=? WHERE id=?"
);
const insertEvent = liveDb.prepare(
  "INSERT INTO alert_events (rule_id, sn, ts, last_seen_ts, message, value) VALUES (?,?,?,?,?,?)"
);
const resolveEvent = liveDb.prepare(
  "UPDATE alert_events SET resolved_ts=?, resolved_reason=? WHERE id=?"
);

function evaluateRules(row: any) {
  const rules = liveDb.prepare("SELECT * FROM alert_rules WHERE enabled=1").all() as any[];
  if (!rules.length) return;
  const now = Date.now();
  for (const rule of rules) {
    const conds = ruleConds(rule);
    const parts: string[] = [];
    let firstV: number | null = null;
    let all = true;
    // only_moving rules can't be evaluated true on a stationary rig, but we must
    // still let a previously-open event resolve when the rig stops — so treat it
    // as "condition not holding" rather than skipping the rule entirely.
    if (rule.only_moving && !row.moved) {
      all = false;
    } else {
      for (const c of conds) {
        const { v, label } = condEval(c, row);
        if (v == null || !condHit(c, v)) { all = false; break; }
        firstV ??= v;
        const disp = c.field === "speed_mph" ? `${v.toFixed(1)} mph` : String(Math.round(v * 1000) / 1000);
        parts.push(`${label} = ${disp}`);
      }
    }
    const key = `${rule.id}:${row.sn}`;
    const open = findOpenEvent.get(rule.id, row.sn) as { id: number } | undefined;

    // Condition no longer holds -> resolve any open event for this rig+rule.
    if (!all) {
      sustainSince.delete(key);
      if (open) resolveEvent.run(now, "condition cleared", open.id);
      continue;
    }

    // Sustain gate: don't open until the condition has held long enough.
    if (rule.sustain_min) {
      const first = sustainSince.get(key) ?? row.ts;
      if (!sustainSince.has(key)) sustainSince.set(key, row.ts);
      const heldMin = (row.ts - first) / 60000;
      if (heldMin < rule.sustain_min) continue;
      parts.push(`held ${Math.round(heldMin)}m`);
    }

    const message = `${rule.name}: ${parts.join(", ")}`;
    if (open) {
      // One open event per rig+rule for the whole episode: just extend it.
      touchOpenEvent.run(row.ts, message, firstV, open.id);
    } else {
      insertEvent.run(rule.id, row.sn, row.ts, row.ts, message, firstV);
    }
  }
}

// Resolve every open event for a rig that is no longer connected. Called each
// cycle for rigs that dropped offline (their rows aren't re-evaluated, so their
// open events would otherwise hang forever — this was the Bill Englert bug).
function resolveOfflineAlerts() {
  const now = Date.now();
  // rule_id=0 = daily log-scan findings (from dailyreport.ts). Those aren't
  // live-condition alerts, so leave them alone — they carry their own history.
  const info = liveDb.prepare(
    `UPDATE alert_events SET resolved_ts=?, resolved_reason='system offline'
     WHERE resolved_ts IS NULL AND rule_id != 0 AND sn IN (
       SELECT sn FROM live_latest WHERE connected IS NOT 1
     )`
  ).run(now);
  return info.changes as number;
}

// Re-run all rules for one rig off its stored row — used by params.ts right
// after a wake-edge param fetch so param rules fire on fresh values.
export function evaluateRulesForSn(sn: string) {
  const row = liveDb.prepare("SELECT * FROM live_latest WHERE sn=?").get(sn) as any;
  if (row?.connected === 1) evaluateRules({ ...row, went_online: 0 });
}

// ---------------- board (latest + rig + customer join) ----------------
export function liveBoard() {
  const rows = liveDb.prepare("SELECT * FROM live_latest ORDER BY moved DESC, connected DESC, ts DESC LIMIT 2000").all() as any[];
  if (!rows.length) return [];
  const sns = rows.map((r) => r.sn);
  const ph = sns.map(() => "?").join(",");
  const rigMap = new Map<string, any>();
  for (const r of db
    .prepare(`SELECT sn, device_name, machine_class, brand_normalized, model, customer_email, customer_contact, city, province FROM rigs WHERE sn IN (${ph})`)
    .all(...sns) as any[]) rigMap.set(r.sn, r);
  const custMap = new Map<string, any>();
  for (const r of liveDb
    .prepare(
      `SELECT cs.sn, c.customer_name, c.hubspot_link, c.address, c.email FROM customer_serials cs JOIN customers c ON c.id=cs.customer_id WHERE cs.sn IN (${ph})`
    )
    .all(...sns) as any[]) custMap.set(r.sn, r);
  // fallback: match customer by rig email
  const emailStmt = liveDb.prepare("SELECT customer_name, hubspot_link, address, email FROM customers WHERE email=? LIMIT 1");
  rigMap.forEach((rig, sn) => {
    if (!custMap.has(sn) && rig.customer_email) {
      const c = emailStmt.get(String(rig.customer_email).toLowerCase()) as Record<string, unknown> | undefined;
      if (c) custMap.set(sn, { sn, ...c });
    }
  });
  // contact info: serial_contacts (HubSpot deal->contact) first, then contacts-by-email fallback
  const contactMap = new Map<string, any>();
  for (const r of liveDb
    .prepare(`SELECT sn, name, email, phone, hubspot_contact_link, hubspot_deal_link, source, confidence, evidence FROM serial_contacts WHERE sn IN (${ph})`)
    .all(...sns) as any[]) contactMap.set(r.sn, r);
  const contactEmailStmt = liveDb.prepare(
    "SELECT name, phone, hubspot_contact_link FROM contacts WHERE email=? AND phone IS NOT NULL LIMIT 1"
  );
  const lookupByEmail = (email: unknown) => {
    if (!email) return undefined;
    return contactEmailStmt.get(String(email).toLowerCase()) as Record<string, unknown> | undefined;
  };
  for (const sn of sns) {
    const existing = contactMap.get(sn);
    if (existing?.phone) continue;
    const rig = rigMap.get(sn);
    const cand =
      lookupByEmail(existing?.email) ?? lookupByEmail(custMap.get(sn)?.email) ?? lookupByEmail(rig?.customer_email);
    if (cand) {
      contactMap.set(sn, {
        sn,
        name: existing?.name ?? cand.name ?? null,
        email: existing?.email ?? null,
        phone: cand.phone ?? null,
        hubspot_contact_link: existing?.hubspot_contact_link ?? cand.hubspot_contact_link ?? null,
        hubspot_deal_link: existing?.hubspot_deal_link ?? null,
        source: existing?.source ?? "contacts-email",
        confidence: existing?.confidence ?? "high",
        evidence: existing?.evidence ?? null,
      });
    }
  }
  const alertCounts = new Map<string, number>();
  for (const r of liveDb
    // Badge count must match the Alerts card: currently-open (unresolved)
    // events only. Counting ack_ts IS NULL inflated it with years of
    // auto-resolved history nobody ever clicked "ack" on.
    .prepare(`SELECT sn, COUNT(*) c FROM alert_events WHERE resolved_ts IS NULL GROUP BY sn`)
    .all() as any[]) alertCounts.set(r.sn, r.c);
  return rows.map((r) => ({
    ...r,
    speed_mph: r.speed_ms != null ? Math.round(r.speed_ms * 2.23694 * 10) / 10 : null,
    rig: rigMap.get(r.sn) ?? null,
    customer: custMap.get(r.sn) ?? null,
    contact: contactMap.get(r.sn) ?? null,
    open_alerts: alertCounts.get(r.sn) ?? 0,
  }));
}

// ---------------- rules / events CRUD ----------------
export function listRules() {
  return liveDb.prepare("SELECT * FROM alert_rules ORDER BY id DESC").all();
}
export function createRule(r: {
  name: string; conditions: RuleCond[]; sustain_min?: number | null; only_moving?: boolean;
}) {
  // First condition mirrors into the legacy columns so old queries/dup checks
  // keep working; the full list is stored as JSON only when compound.
  const [first] = r.conditions;
  const info = liveDb
    .prepare(
      "INSERT INTO alert_rules (name, field, op, value, value2, enabled, only_moving, created_ts, conditions, sustain_min) VALUES (?,?,?,?,?,1,?,?,?,?)"
    )
    .run(
      r.name, first.field, first.op, first.value, first.value2 ?? null, r.only_moving ? 1 : 0, Date.now(),
      r.conditions.length > 1 ? JSON.stringify(r.conditions) : null,
      r.sustain_min ?? null
    );
  return liveDb.prepare("SELECT * FROM alert_rules WHERE id=?").get(info.lastInsertRowid);
}
export function toggleRule(id: number, enabled: boolean) {
  liveDb.prepare("UPDATE alert_rules SET enabled=? WHERE id=?").run(enabled ? 1 : 0, id);
}
export function deleteRule(id: number) {
  liveDb.prepare("DELETE FROM alert_rules WHERE id=?").run(id);
  liveDb.prepare("DELETE FROM alert_events WHERE rule_id=?").run(id);
}
// Seed a starter set of rules that reflect the signals Joey asked for.
// Skips any rule whose (field, op, value) already exists — safe to click twice.
export function seedDefaultRules() {
  const defaults = [
    // GPS quality
    { name: "Low satellites (< 20) while moving", field: "satellites", op: "lt", value: 20, only_moving: 1 },
    // RTK dropout: rtk_status 4 = FIXED. Anything below is degraded.
    { name: "RTK degraded (not FIXED) while moving", field: "rtk_status", op: "lt", value: 4, only_moving: 1 },
    // Speed anomaly (rough — tune per crop later)
    { name: "Speed too high (> 12 mph) while moving", field: "speed_mph", op: "gt", value: 12, only_moving: 1 },
    { name: "Speed too low (< 1 mph) while working", field: "speed_mph", op: "lt", value: 1, only_moving: 1 },
    // Terminal disconnect (connected=0). Runs on every row (only_moving=0).
    { name: "Terminal disconnected", field: "connected", op: "eq", value: 0, only_moving: 0 },
    // Stale rig: hasn't reported for over 6 hours
    { name: "Rig stale > 6h (no DMS update)", field: "stale_minutes", op: "gt", value: 360, only_moving: 0 },
    // Any error-level fault in the last 24h (error_category 3 = error)
    { name: "Error-level fault in last 24h", field: "fault_severity", op: "gt", value: 2, only_moving: 0 },
    // Any fault activity in the last 24h
    { name: "3+ faults in last 24h", field: "fault_count_24h", op: "gt", value: 2, only_moving: 0 },
    // Parameter watches — fire on wake when the value falls outside the safe band.
    { name: "Online Aggressiveness outside 0.6–1.6", field: "param.lateralSensitivity", op: "outside", value: 0.6, value2: 1.6, only_moving: 0 },
    { name: "Tuning parameter > 200", field: "param.vehicleCalibration1", op: "gt", value: 200, only_moving: 0 },
  ];
  let added = 0;
  let skipped = 0;
  const dupStmt = liveDb.prepare("SELECT id FROM alert_rules WHERE field=? AND op=? AND value=?");
  const insStmt = liveDb.prepare(
    "INSERT INTO alert_rules (name, field, op, value, value2, enabled, only_moving, created_ts) VALUES (?,?,?,?,?,1,?,?)"
  );
  for (const d of defaults) {
    if (dupStmt.get(d.field, d.op, d.value)) { skipped++; continue; }
    insStmt.run(d.name, d.field, d.op, d.value, (d as any).value2 ?? null, d.only_moving, Date.now());
    added++;
  }
  return { added, skipped, total: defaults.length };
}
// Unified event query. `scope`:
//   'open'  -> currently-active alerts (resolved_ts IS NULL) — the LIVE view.
//   'all'   -> everything, newest first — the history table.
//   'daily' -> events that fired OR resolved within [sinceTs, untilTs) — the
//              daily log for reports / pattern-hunting. Defaults to today.
// Every row carries fired_ts, last_seen_ts, resolved_ts, resolved_reason and a
// derived duration_min so the UI can render timestamps without extra math.
export function listEvents(
  opts: { scope?: "open" | "all" | "daily"; sinceTs?: number; untilTs?: number; limit?: number } = {}
) {
  const scope = opts.scope ?? "all";
  const limit = opts.limit ?? 500;
  let where = "";
  const args: any[] = [];
  if (scope === "open") {
    where = "WHERE e.resolved_ts IS NULL";
  } else if (scope === "daily") {
    const startOfToday = new Date(); startOfToday.setHours(0, 0, 0, 0);
    const since = opts.sinceTs ?? startOfToday.getTime();
    const until = opts.untilTs ?? (since + 86400e3);
    where = "WHERE (e.ts >= ? AND e.ts < ?) OR (e.resolved_ts >= ? AND e.resolved_ts < ?)";
    args.push(since, until, since, until);
  }
  const events = liveDb
    .prepare(
      `SELECT e.*, e.ts AS fired_ts, r.name AS rule_name
         FROM alert_events e LEFT JOIN alert_rules r ON r.id=e.rule_id
         ${where} ORDER BY e.ts DESC LIMIT ?`
    )
    .all(...args, limit) as any[];
  if (!events.length) return [];
  const sns = Array.from(new Set(events.map((e) => e.sn)));
  const ph = sns.map(() => "?").join(",");
  const rigMap = new Map<string, any>();
  for (const r of db.prepare(`SELECT sn, device_name, customer_contact, city FROM rigs WHERE sn IN (${ph})`).all(...sns) as any[])
    rigMap.set(r.sn, r);
  return events.map((e) => {
    const endTs = e.resolved_ts ?? e.last_seen_ts ?? e.ts;
    const duration_min = e.ts ? Math.max(0, Math.round((endTs - e.ts) / 60000)) : null;
    return {
      ...e,
      rig: rigMap.get(e.sn) ?? null,
      status: e.resolved_ts ? "resolved" : "open",
      duration_min,
    };
  });
}
// Manual clear from the alert panel: resolve the event now (reason 'manual').
export function ackEvent(id: number) {
  const now = Date.now();
  liveDb.prepare(
    "UPDATE alert_events SET ack_ts=COALESCE(ack_ts,?), resolved_ts=COALESCE(resolved_ts,?), resolved_reason=COALESCE(resolved_reason,'manual') WHERE id=?"
  ).run(now, now, id);
}
export function ackAllEvents() {
  const now = Date.now();
  liveDb.prepare(
    "UPDATE alert_events SET ack_ts=COALESCE(ack_ts,?), resolved_ts=?, resolved_reason='manual' WHERE resolved_ts IS NULL"
  ).run(now, now);
}

// resume poller on boot if it was running
if (state.running) setTimeout(() => void cycle(), 3000);
